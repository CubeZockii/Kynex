import discord
from discord.ext import commands
from discord.utils import escape_markdown
import datetime
import json
from typing import Optional, Union, List


# --- Official ModEngine Server and Channel IDs ---
MODENGINE_SERVER_ID = 1280076889251119206
MODENGINE_ERROR_LOGS_CHANNEL_ID = 1419730646275719351


class LoggingCog(commands.Cog):
    def __init__(self, bot: commands.Bot, action_log_names: List[str], error_log_names: List[str]):
        self.bot = bot
        self.action_log_channel_names = action_log_names
        self.error_log_channel_names = error_log_names
        
        self.server_configs_file = "server_configs.json"
        self.server_log_channels = self._load_server_configs()
        
        print(f"LoggingCog Initialized.")
        print(f"-> Fallback action log names: {self.action_log_channel_names}")
        print(f"-> Fallback error log names: {self.error_log_channel_names}")
        print(f"-> Loaded {len(self.server_log_channels)} server-specific log configurations.")

    async def _get_specific_log_channel(self, guild: Optional[discord.Guild], channel_type: str) -> Optional[discord.TextChannel]:
        """
        Finds a log channel in a guild.
        Prioritizes server-specific ID config, then falls back to name matching.
        'channel_type' should be 'action' or 'error'.
        """
        if not guild:
            return None

        # 1. Check for server-specific channel ID (PRIMARY LOOKUP)
        server_id = str(guild.id)

        # FIX: Map channel_type to the actual key names used in storage
        key_mapping = {
            'action': 'action_log_channel_id',
            'error': 'error_log_channel_id'
        }

        storage_key = key_mapping.get(channel_type)

        if server_id in self.server_log_channels and storage_key in self.server_log_channels[server_id]:
            channel_id = self.server_log_channels[server_id][storage_key]
            # print(f"LogCog: Found {channel_type} log channel ID in config: {channel_id} for guild {guild.name}") # REMOVED

            # --- BEST PRACTICE: Try cache first, then API ---
            channel = self.bot.get_channel(channel_id)

            if not channel:
                # Channel not in cache, try fetching from API
                try:
                    channel = await self.bot.fetch_channel(channel_id)
                    # print(f"LogCog: Fetched {channel_type} log channel from API for guild {guild.name} ({guild.id})") # REMOVED
                except discord.NotFound:
                    # print(f"LogCog Warning: Configured {channel_type} log channel ID {channel_id} for guild {guild.name} ({guild.id}) no longer exists. Falling back to name search.") # REMOVED
                    channel = None
                except discord.Forbidden:
                    # print(f"LogCog Warning: No permission to access {channel_type} log channel ID {channel_id} for guild {guild.name} ({guild.id}). Falling back to name search.") # REMOVED
                    channel = None
                except Exception as e:
                    # print(f"LogCog Warning: Error fetching {channel_type} log channel ID {channel_id} for guild {guild.name} ({guild.id}): {e}. Falling back to name search.") # REMOVED
                    channel = None

            if channel:
                # print(f"LogCog: Successfully resolved {channel_type} log channel: #{channel.name} ({channel.id})") # REMOVED
                return channel

        # 2. Fallback to channel name (ROBUST CASE-INSENSITIVE SEARCH)
        fallback_channel_names = self.error_log_channel_names if channel_type == 'error' else self.action_log_channel_names
        fallback_names_lower = {name.lower() for name in fallback_channel_names}

        for channel in guild.channels:
            if isinstance(channel, (discord.TextChannel, discord.ForumChannel)):
                if channel.name.lower() in fallback_names_lower:
                    # print(f"LogCog: Found {channel_type} log channel by name fallback: #{channel.name}") # REMOVED
                    return channel

        # print(f"LogCog: {channel_type.capitalize()} log channel not found for guild '{guild.name}' ({guild.id}).") # REMOVED
        return None
    
    async def get_action_log_channel(self, guild: Optional[discord.Guild]) -> Optional[discord.TextChannel]:
        return await self._get_specific_log_channel(guild, 'action')

    async def get_error_log_channel(self, guild: Optional[discord.Guild]) -> Optional[discord.TextChannel]:
        return await self._get_specific_log_channel(guild, 'error')

    # NEW METHOD: Update guild log channels in the cache
    async def update_guild_log_channels(self, guild_id: int, action_channel_id: Optional[int], error_channel_id: Optional[int]):
        """Updates the log channel configuration for a specific guild."""
        guild_id_str = str(guild_id)
        
        if guild_id_str not in self.server_log_channels:
            self.server_log_channels[guild_id_str] = {}
        
        if action_channel_id is not None:
            self.server_log_channels[guild_id_str]['action_log_channel_id'] = action_channel_id
            #print(f"LogCog: Updated action log channel for guild {guild_id}: {action_channel_id}")
        
        if error_channel_id is not None:
            self.server_log_channels[guild_id_str]['error_log_channel_id'] = error_channel_id
            #print(f"LogCog: Updated error log channel for guild {guild_id}: {error_channel_id}")

    def create_embed(self, title: str, description: str, color: discord.Color, 
                     actor: Optional[discord.User] = None, thumbnail_url: Optional[str] = None,
                     ctx_or_interaction: Optional[Union[commands.Context, discord.Interaction]] = None) -> discord.Embed:
        embed = discord.Embed(title=f"**{title}**", description=description, color=color)
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        if actor:
            embed.set_author(name=f"{actor.display_name}", icon_url=actor.display_avatar.url)
        if thumbnail_url:
            embed.set_thumbnail(url=thumbnail_url)
        return embed
    
    async def log_command_execution(self, ctx_or_interaction: Union[commands.Context, discord.Interaction], success: bool, command_name: str, details: str = "", target: Optional[Union[discord.Member, discord.User, discord.TextChannel, str]] = None):
        """Logs the execution of a command."""
        guild = ctx_or_interaction.guild
        if not guild: return 

        log_channel = await self.get_action_log_channel(guild)
        if not log_channel:
            print(f"LogCog: Action log channel not found for guild '{guild.name}' ({guild.id}).")
            return

        status_emoji = "✅" if success else "❌"
        title = f"{status_emoji} Command: {command_name}" 
        color = discord.Color.green() if success else discord.Color.orange()
        
        actor = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author
        channel_obj = ctx_or_interaction.channel 

        description_parts = [f"**User:** {actor.mention} (`{actor.id}`)"] 
        channel_mention = channel_obj.mention if hasattr(channel_obj, 'mention') else (f"`#{channel_obj.name}`" if hasattr(channel_obj, 'name') else "N/A")
        description_parts.append(f"**In:** {channel_mention}")

        if target:
            if isinstance(target, (discord.Member, discord.User)):
                description_parts.append(f"**Target User:** {target.mention} (`{target.id}`)") 
            elif isinstance(target, discord.TextChannel):
                description_parts.append(f"**Target Channel:** {target.mention}") 
            else:
                description_parts.append(f"**Target/Info:** `{str(target)}`")
        if details:
            description_parts.append(f"**Details:** {details}")

        embed = self.create_embed(title, "\n".join(description_parts), color, actor=actor, ctx_or_interaction=ctx_or_interaction)
        try:
            await log_channel.send(embed=embed)
        except Exception as e:
            print(f"LogCog: Error sending command execution log to {log_channel.name} in {guild.name}: {e}")

    def _load_server_configs(self):
        try:
            with open(self.server_configs_file, "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
        
    def _save_server_configs(self):
        try:
            with open(self.server_configs_file, "w") as f:
                json.dump(self.server_log_channels, f, indent=4)
        except Exception as e:
            print(f"LogCog: Error saving server configs to file: {e}")

    def update_log_channel(self, guild_id: int, channel_type: str, channel_id: int):
        """Updates or creates a specific log channel entry and saves the config."""
        guild_id_str = str(guild_id)
        if guild_id_str not in self.server_log_channels:
            self.server_log_channels[guild_id_str] = {}
            
        self.server_log_channels[guild_id_str][channel_type] = channel_id
        self._save_server_configs()
        print(f"LogCog: Updated log channel for guild {guild_id}: {channel_type}={channel_id}. Config saved.")

    async def log_error(self, guild: Optional[discord.Guild], title: str, description: str,
                    field_dict: Optional[dict] = None, ctx_or_interaction: Optional[Union[commands.Context, discord.Interaction]] = None):
        """
        Logs an error message to the server's designated error channel. If the error did not
        originate from the ModEngine server, it also sends a shared log to the official channel.
        """
        is_modengine_server = guild and guild.id == MODENGINE_SERVER_ID

        if guild:
            log_channel = await self._get_specific_log_channel(guild, 'error')
            if log_channel:
                local_embed = self._create_log_embed("Error", title, description, field_dict, ctx_or_interaction)
                try:
                    await log_channel.send(embed=local_embed)
                except Exception as e:
                    print(f"LogCog: Error sending log to {log_channel.name} in {guild.name}: {e}")

        if not is_modengine_server:
            modengine_guild = self.bot.get_guild(MODENGINE_SERVER_ID)
            modengine_channel = self.bot.get_channel(MODENGINE_ERROR_LOGS_CHANNEL_ID)

            if modengine_guild and modengine_channel:
                official_embed = self._create_log_embed("Error", title, description, field_dict, ctx_or_interaction)
                guild_name = guild.name if guild else "Direct Message / Unknown Guild"
                official_embed.add_field(name="Origin Guild", value=f"{escape_markdown(guild_name)} (`{guild.id if guild else 'N/A'}`)", inline=False)
                
                try:
                    await modengine_channel.send(embed=official_embed)
                except Exception as e:
                    print(f"LogCog: Error sending log to the official ModEngine channel: {e}")
            else:
                print("Warning: Official ModEngine server or error log channel not found. Please check the IDs.")
        
    def _create_log_embed(self, log_type: str, title: str, description: str, 
                          field_dict: Optional[dict] = None, ctx_or_interaction: Optional[Union[commands.Context, discord.Interaction]] = None) -> discord.Embed:
        """Helper to create a formatted log embed."""
        embed_color = discord.Color.red() if log_type == "Error" else discord.Color.blue()
        embed = discord.Embed(title=f"**{title}**", description=description, color=embed_color)
        embed.set_footer(text=f"Log Type: {log_type}")
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        
        if ctx_or_interaction:
            user = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author
            embed.set_author(name=f"{user.display_name}", icon_url=user.display_avatar.url)
            
        if field_dict:
            for name, value in field_dict.items():
                embed.add_field(name=name, value=value, inline=False)
        return embed

    def _get_or_create_log_embed(self, title: str, description: str, color: discord.Color) -> discord.Embed:
        """Helper to get or create a log embed. DEPRECATED but kept for backwards compatibility."""
        return discord.Embed(title=title, description=description, color=color)

    async def _send_moderation_action_log(self, guild: discord.Guild, embed: discord.Embed, mod_action: str):
        """Helper to send a moderation action log to the relevant channel."""
        log_channel = await self._get_specific_log_channel(guild, 'action')
        if log_channel:
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog: Error sending specific moderation action log to {log_channel.name} in {guild.name}: {e}")
    
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Logs when a member joins the guild."""
        log_channel = await self.get_action_log_channel(member.guild)
        if log_channel:
            embed = self.create_embed("🔥 Member Joined", f"{member.mention} (`{member.id}`) joined.", discord.Color.green(), actor=member)
            try: await log_channel.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_join): {e}")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        log_channel = await self.get_action_log_channel(member.guild)
        if log_channel:
            action_by_str = "Unknown"
            reason_str = "Left the server"
            action_found = False
            
            try:
                async for entry in member.guild.audit_logs(limit=1, action=discord.AuditLogAction.kick, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=10)):
                    if entry.target and entry.target.id == member.id:
                        action_by_str = entry.user.mention if entry.user else "Unknown Moderator"
                        reason_str = f"was kicked (Reason: {entry.reason or 'N/A'})"
                        action_found = True
                        break
                
                if not action_found:
                    async for entry in member.guild.audit_logs(limit=1, action=discord.AuditLogAction.ban, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=10)):
                        if entry.target and entry.target.id == member.id:
                            action_by_str = entry.user.mention if entry.user else "Unknown Moderator"
                            reason_str = f"was banned (Reason: {entry.reason or 'N/A'})"
                            action_found = True
                            break
            except discord.Forbidden: 
                reason_str += " (Audit log access denied)"
                print(f"LogCog: Missing permissions to read audit logs in guild {member.guild.name} for on_member_remove.")
            except Exception as e: 
                print(f"LogCog: Audit log fetch error for member remove: {type(e).__name__} - {e}")

            desc = f"{member.mention} (`{member.id}`) {reason_str}."
            if action_found and action_by_str != "Unknown":
                desc += f"\n**Action by:** {action_by_str}"
            
            embed = self.create_embed("🔤 Member Left/Removed", desc, discord.Color.red(), actor=member)
            try: await log_channel.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_remove send): {e}")
    
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        """Logs when a message is deleted."""
        if message.guild and not message.author.bot and (message.content or message.attachments or message.embeds):
            log_channel = await self.get_action_log_channel(message.guild)
            if log_channel:
                content = escape_markdown(message.content) if message.content else ""
                if message.attachments: 
                    content += f"\n*({len(message.attachments)} attachment(s))* "
                    for att in message.attachments:
                        content += f"\n- {att.filename} (`{att.url}`)"
                if message.embeds and not message.content: 
                    content += "\n*Message contained an embed.*"
                if not content.strip(): 
                    content = "*No displayable content (e.g., only sticker or complex embed)*"

                if len(content) > 1000: content = content[:1000] + "..."
                
                embed = self.create_embed(
                    "🗑️ Message Deleted",
                    f"**Author:** {message.author.mention} (`{message.author.id}`)\n"
                    f"**Channel:** {message.channel.mention}\n\n"
                    f"**Content**\n{content}",
                    discord.Color.orange(),
                    actor=message.author,
                    thumbnail_url=None 
                )
                try: await log_channel.send(embed=embed)
                except Exception as e: print(f"LogCog Error (on_message_delete): {e}")

    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages: List[discord.Message]):
        """Logs when multiple messages are deleted (bulk delete)."""
        if not messages: return
        guild = messages[0].guild
        if not guild: return
        log_channel = await self.get_action_log_channel(guild)
        if not log_channel: return
        
        source_channel_mention = messages[0].channel.mention if messages[0].channel else "Unknown Channel"
        count = len(messages)
        embed = self.create_embed(
            "🗑️ Bulk Messages Deleted",
            f"**{count}** messages were deleted in {source_channel_mention}.",
            discord.Color.dark_orange(),
            actor=self.bot.user,
            thumbnail_url=None
        )
        try: await log_channel.send(embed=embed)
        except Exception as e: print(f"LogCog Error (on_bulk_message_delete): {e}")

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        """Logs when a message is edited."""
        if before.guild and not before.author.bot and before.content != after.content:
            log_channel = await self.get_action_log_channel(before.guild)
            if log_channel:
                before_content = escape_markdown(before.content) if before.content else "*Empty*"
                after_content = escape_markdown(after.content) if after.content else "*Empty*"
                if len(before_content) > 500: before_content = before_content[:500] + "..."
                if len(after_content) > 500: after_content = after_content[:500] + "..."
                embed = self.create_embed(
                    "✏️ Message Edited",
                    f"**Author:** {before.author.mention} (`{before.author.id}`)\n"
                    f"**Channel:** {before.channel.mention} [Jump to Message]({after.jump_url})\n\n"
                    f"**Before**\n{before_content}\n\n"
                    f"**After**\n{after_content}\n",
                    discord.Color.blue(),
                    actor=before.author,
                    thumbnail_url=None
                )
                try: await log_channel.send(embed=embed)
                except Exception as e: print(f"LogCog Error (on_message_edit): {e}")

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        """Logs when a channel is created."""
        log_ch = await self.get_action_log_channel(channel.guild)
        if log_ch:
            ch_type = "Text" if isinstance(channel, discord.TextChannel) else \
                      "Voice" if isinstance(channel, discord.VoiceChannel) else \
                      "Category" if isinstance(channel, discord.CategoryChannel) else \
                      "Stage" if isinstance(channel, discord.StageChannel) else \
                      "Forum" if isinstance(channel, discord.ForumChannel) else "Unknown"
            embed = self.create_embed(f"🔗 {ch_type} Channel Created", f"{ch_type} channel created: {channel.mention} (`{channel.name}`)", discord.Color.dark_green(), actor=self.bot.user)
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_channel_create): {e}")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        """Logs when a channel is deleted."""
        log_ch = await self.get_action_log_channel(channel.guild)
        if log_ch:
            ch_type = "Text" if isinstance(channel, discord.TextChannel) else \
                      "Voice" if isinstance(channel, discord.VoiceChannel) else \
                      "Category" if isinstance(channel, discord.CategoryChannel) else \
                      "Stage" if isinstance(channel, discord.StageChannel) else \
                      "Forum" if isinstance(channel, discord.ForumChannel) else "Unknown"
            embed = self.create_embed(f"🔕 {ch_type} Channel Deleted", f"{ch_type} channel deleted: `#{channel.name}` ({channel.id})", discord.Color.dark_red(), actor=self.bot.user)
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_channel_delete): {e}")
            
    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        """Logs when a channel's name or type is updated."""
        log_channel = await self.get_action_log_channel(before.guild)
        if not log_channel:
            return

        changes = []
        
        if before.name != after.name:
            changes.append(f"**Name:** `#{before.name}` → `#{after.name}`")

        if before.type != after.type:
            changes.append(f"**Type:** `{before.type.name.capitalize()}` → `{after.type.name.capitalize()}`")

        if isinstance(before, discord.TextChannel) and isinstance(after, discord.TextChannel):
            if before.category != after.category:
                before_cat_name = before.category.name if before.category else "None"
                after_cat_name = after.category.name if after.category else "None"
                changes.append(f"**Category:** `{before_cat_name}` → `{after_cat_name}`")
        if isinstance(before, discord.TextChannel) and isinstance(after, discord.TextChannel):
            if before.topic != after.topic:
                changes.append(f"**Topic changed.**")
            if before.nsfw != after.nsfw:
                changes.append(f"**NSFW status:** `{before.nsfw}` → `{after.nsfw}`")
        if isinstance(before, discord.VoiceChannel) and isinstance(after, discord.VoiceChannel):
            if before.bitrate != after.bitrate:
                changes.append(f"**Bitrate:** `{before.bitrate // 1000}kbps` → `{after.bitrate // 1000}kbps`")
            if before.user_limit != after.user_limit:
                changes.append(f"**User Limit:** `{before.user_limit or 'None'}` → `{after.user_limit or 'None'}`")

        if changes:
            ch_type = "Text" if isinstance(after, discord.TextChannel) else \
                      "Voice" if isinstance(after, discord.VoiceChannel) else \
                      "Category" if isinstance(after, discord.CategoryChannel) else \
                      "Stage" if isinstance(after, discord.StageChannel) else \
                      "Forum" if isinstance(after, discord.ForumChannel) else "Unknown"
            
            embed_desc = f"**Channel:** {after.mention} (`{after.id}`)\n\n" + "\n".join(changes)
            embed = self.create_embed(f"🔄 {ch_type} Channel Updated", embed_desc, discord.Color.teal(), actor=self.bot.user)
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog Error (on_guild_channel_update): {e}")
    
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        """Logs when a role is created."""
        log_ch = await self.get_action_log_channel(role.guild)
        if log_ch:
            embed = self.create_embed("➕ Role Created", f"New role: {role.mention} (`{role.name}`)", discord.Color.green(), actor=self.bot.user)
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_role_create): {e}")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        """Logs when a role is deleted."""
        log_ch = await self.get_action_log_channel(role.guild)
        if log_ch:
            embed = self.create_embed("➖ Role Deleted", f"Role deleted: `{role.name}` ({role.id})", discord.Color.red(), actor=self.bot.user)
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_role_delete): {e}")
            
    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        """Logs when a role is updated, including specific permission changes."""
        log_channel = await self.get_action_log_channel(after.guild)
        if not log_channel:
            return

        changes = []

        if before.name != after.name:
            changes.append(f"**Name:** `{before.name}` → `{after.name}`")

        if before.color != after.color:
            changes.append(f"**Color:** `{before.color}` → `{after.color}`")

        if before.permissions != after.permissions:
            perm_changes_list = []
            
            for perm_name, value in iter(discord.Permissions()):
                before_has_perm = getattr(before.permissions, perm_name)
                after_has_perm = getattr(after.permissions, perm_name)

                if before_has_perm != after_has_perm:
                    if after_has_perm:
                        perm_changes_list.append(f"• **`{perm_name.replace('_', ' ').title()}`**: Granted ✅")
                    else:
                        perm_changes_list.append(f"• **`{perm_name.replace('_', ' ').title()}`**: Revoked ❌")
            
            if perm_changes_list:
                changes.append(f"**Permissions changed:**\n" + "\n".join(perm_changes_list))
            else:
                changes.append("**Permissions changed** (details not available due to internal mismatch, or no granular changes detected)")

        if before.hoist != after.hoist:
            changes.append(f"**Display separately:** `{before.hoist}` → `{after.hoist}`")

        if before.mentionable != after.mentionable:
            changes.append(f"**Mentionable:** `{before.mentionable}` → `{after.mentionable}`")

        if changes:
            embed = self.create_embed(
                "🛠️ Role Updated",
                f"**Role:** {after.mention}\n\n" + "\n".join(changes),
                discord.Color.orange(),
                actor=self.bot.user
            )
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog Error (on_guild_role_update): {e}")
            
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Logs when a member's profile (nickname, roles, etc.) is updated."""
        log_channel = await self.get_action_log_channel(after.guild)
        if not log_channel:
            return

        changes = []

        if before.nick != after.nick:
            changes.append(f"**Nickname changed:** `{before.nick or 'None'}` → `{after.nick or 'None'}`")

        added_roles = [r for r in after.roles if r not in before.roles]
        removed_roles = [r for r in before.roles if r not in after.roles]

        if added_roles:
            changes.append(f"**Roles added:** {', '.join(r.mention for r in added_roles)}")
        if removed_roles:
            changes.append(f"**Roles removed:** {', '.join(r.mention for r in removed_roles)}")

        if changes:
            embed = self.create_embed(
                "👤 Member Updated", 
                f"**Member:** {after.mention} (`{after.id}`)\n\n" + "\n".join(changes), 
                discord.Color.blurple(), 
                actor=after
            )
            try: await log_channel.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_update): {e}")
    
    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: Union[discord.User, discord.Member]):
        """Logs when a member is banned."""
        log_ch = await self.get_action_log_channel(guild)
        if log_ch:
            reason, moderator = "N/A", "Unknown"
            try:
                async for entry in guild.audit_logs(action=discord.AuditLogAction.ban, limit=1, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=5)):
                    if entry.target.id == user.id:
                        reason = entry.reason or "No reason provided"
                        moderator = entry.user.mention if entry.user else "Unknown"
                        break
            except discord.Forbidden: 
                print(f"LogCog: Missing permissions to read audit logs for ban event in guild {guild.name}.")
            except Exception as e: 
                print(f"LogCog Error (on_member_ban audit log): {e}")

            embed = self.create_embed("🔨 Member Banned", f"{user.mention} (`{user.id}`) was banned.\n**Moderator:** {moderator}\n**Reason:** {reason}", discord.Color.dark_red(), actor=user)
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_ban event): {e}")

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        """Logs when a member is unbanned."""
        log_ch = await self.get_action_log_channel(guild)
        if log_ch:
            reason, moderator = "N/A", "Unknown"
            try:
                async for entry in guild.audit_logs(action=discord.AuditLogAction.unban, limit=1, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=5)):
                    if entry.target.id == user.id:
                        reason = entry.reason or "No reason provided"
                        moderator = entry.user.mention if entry.user else "Unknown"
                        break
            except discord.Forbidden: 
                print(f"LogCog: Missing permissions to read audit logs for unban event in guild {guild.name}.")
            except Exception as e: 
                print(f"LogCog Error (on_member_unban audit log): {e}")

            embed = self.create_embed("✅ Member Unbanned", f"{user.mention} (`{user.id}`) was unbanned.\n**Moderator:** {moderator}\n**Reason:** {reason}", discord.Color.dark_green(), actor=user)
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_unban event): {e}")
    
    async def log_moderation_action(self, 
                                    ctx_or_interaction: Union[commands.Context, discord.Interaction], 
                                    title: str, description: str, color: discord.Color,
                                    target_user: Union[discord.Member, discord.User]):
        """A generic function to log various moderation actions."""
        guild = ctx_or_interaction.guild
        if not guild: return
        log_channel = await self.get_action_log_channel(guild)
        if log_channel:
            moderator = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author
            desc_with_mod = f"**Moderator:** {moderator.mention} (`{moderator.id}`)\n" \
                            f"**Target:** {target_user.mention} (`{target_user.id}`)\n" \
                            f"{description}"
            thumbnail_url_to_use = target_user.display_avatar.url if hasattr(target_user, 'display_avatar') and target_user.display_avatar else None
            embed = self.create_embed(title, desc_with_mod, color, actor=moderator, thumbnail_url=thumbnail_url_to_use, ctx_or_interaction=ctx_or_interaction)
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog: Error sending specific moderation action log to {log_channel.name} in {guild.name}: {e}")

async def setup(bot: commands.Bot):
    """Sets up the LoggingCog with action and error log channel names from config.json."""
    action_log_names, error_log_names = [], []
    try:
        with open("config.json", "r") as f: 
            config = json.load(f)
        action_log_names = config.get("ACTION_LOG_CHANNEL_NAMES", [])
        error_log_names = config.get("ERROR_LOG_CHANNEL_NAMES", [])
        if not isinstance(action_log_names, list): 
            print("Warning: ACTION_LOG_CHANNEL_NAMES in config.json is not a list. Using empty list.")
            action_log_names = []
        if not isinstance(error_log_names, list): 
            print("Warning: ERROR_LOG_CHANNEL_NAMES in config.json is not a list. Using empty list.")
            error_log_names = []
    except FileNotFoundError:
        print("LogCog Setup: config.json not found. Using empty channel lists.")
    except json.JSONDecodeError:
        print("LogCog Setup: Error decoding config.json. Please check its format. Using empty channel lists.")
    except Exception as e: 
        print(f"LogCog Setup: Unexpected error loading config: {e}. Using empty channel lists.")
    
    await bot.add_cog(LoggingCog(bot, action_log_names, error_log_names))