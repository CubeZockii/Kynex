import discord
from discord.ext import commands, tasks 
from discord import app_commands 
import json
import os
import asyncio
import itertools 
import pyfiglet 
import datetime 

CONFIG_FILE = "config.json"
config_data = {}
try:
    with open(CONFIG_FILE, "r") as f: config_data = json.load(f)
except FileNotFoundError:
    print(f"CRITICAL ERROR: {CONFIG_FILE} not found. Please create it based on the example.")
    exit()
except json.JSONDecodeError:
    print(f"CRITICAL ERROR: Could not decode {CONFIG_FILE}. Check its format.")
    exit()
except Exception as e:
    print(f"CRITICAL ERROR: Failed to load config: {e}")
    exit()

BOT_TOKEN = config_data.get("BOT_TOKEN")
DEFAULT_PREFIX = config_data.get("DEFAULT_PREFIX", "~")
PREFIXES_FILE = config_data.get("PREFIXES_FILE", "prefixes.json")

if not BOT_TOKEN or BOT_TOKEN == "YOUR_BOT_TOKEN_HERE": 
    print("CRITICAL ERROR: BOT_TOKEN is not configured in config.json.")
    exit()

activity_list = [
    discord.Activity(type=discord.ActivityType.playing, name="Managment Bot"),
    discord.Activity(type=discord.ActivityType.watching, name="over Servers"),
]
activities = itertools.cycle(activity_list)   
    
server_prefixes_cache = {} 
def load_prefixes():
    global server_prefixes_cache
    if not os.path.exists(PREFIXES_FILE):
        try:
            with open(PREFIXES_FILE, "w") as f: json.dump({}, f)
            server_prefixes_cache = {}
        except IOError: server_prefixes_cache = {}
        return server_prefixes_cache 
    try:
        with open(PREFIXES_FILE, "r") as f: data = json.load(f)
        server_prefixes_cache = data
        return data
    except (json.JSONDecodeError, IOError):
        server_prefixes_cache = {}
        return {} 
load_prefixes()

async def get_prefix(bot_instance, message: discord.Message):
    if not message.guild:
        return commands.when_mentioned_or(DEFAULT_PREFIX)(bot_instance, message)
    
    guild_id_str = str(message.guild.id)
    server_prefix = bot_instance.server_prefixes_cache.get(guild_id_str)
    
    # If a server prefix is set and it's different from the default prefix,
    # return a list containing both. Otherwise, just return the default.
    if server_prefix and server_prefix != DEFAULT_PREFIX:
        return commands.when_mentioned_or(server_prefix, DEFAULT_PREFIX)(bot_instance, message)
    
    # If no server prefix or it's same as default, only respond to default and mentions
    return commands.when_mentioned_or(DEFAULT_PREFIX)(bot_instance, message)

class ModBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = True
        intents.guilds = True
        super().__init__(command_prefix=get_prefix, intents=intents, help_command=None)
        
        # Move the server prefixes cache into the bot instance
        self.server_prefixes_cache = server_prefixes_cache

    async def setup_hook(self):
        """This is called once when the bot first starts."""
        initial_extensions = ["logging_cog", "commands_cog"]
        for extension in initial_extensions:
            try:
                await self.load_extension(extension)
                print(f"Successfully loaded: {extension}")
            except Exception as e:
                print(f"CRITICAL: Failed to load extension {extension}: {type(e).__name__} - {e}")
        
        # Sync slash commands here, only once.
        try:
            synced = await self.tree.sync()
            print(f"✅ Synced {len(synced)} slash commands globally.")
        except Exception as e:
            print(f"❌ Error syncing slash commands: {e}")

    async def on_ready(self):
        """This is called every time the bot connects or reconnects."""
        # This is now safe to run multiple times.
        if not change_status.is_running():
            change_status.start()
        
        header = pyfiglet.figlet_format("Kynex", font="slant")
        print(header)
        print(f"✅ Logged in as: {self.user.name} ({self.user.id})")
        print(f"📎 Default Prefix: {DEFAULT_PREFIX}")
        print(f"📦 discord.py Version: {discord.__version__}")
        print(f"🌐 **Connected to {len(self.guilds)} server(s)**")

        # --- Loop through all connected guilds to show details ---
        if self.guilds:
            print("\n📝 **Server List**:")
            for i, guild in enumerate(self.guilds, 1):
                # f-string formatting to align the output neatly:
                # {i:>4} right-aligns the number in a 4-character space
                # {guild.name:<30} left-aligns the name in a 30-character space
                # {guild.id} is the server ID
                print(f"    {i:>4}. {guild.name:<30} | ID: {guild.id}")
        # --------------------------------------------------------

        logging_cog = self.get_cog("LoggingCog")
        if logging_cog:
            print(f"📋 Action Log Channel Names configured: {logging_cog.action_log_channel_names}")
            print(f"Error Log Channel Names configured: {logging_cog.error_log_channel_names}")
            # Optional: You might want to prevent this log message on every reconnect
            # await logging_cog.log_custom_event(...)
        else:
            print("ERROR: LoggingCog not found at on_ready.")

        print("🚀 Bot is fully operational.")

# --- INITIALIZE THE BOT ---
bot = ModBot()

# --- TASKS AND EVENTS (Now attached to the 'bot' instance) ---

@tasks.loop(minutes=15)
async def change_status():
    activity = next(activities)
    await bot.change_presence(activity=activity, status=discord.Status.online)

@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError):
    logging_cog = bot.get_cog("LoggingCog")
    user_msg = "An unexpected error occurred with that command."
    log_err_flag = True 

    if isinstance(error, commands.CommandNotFound): log_err_flag = False 
    elif isinstance(error, commands.MissingRequiredArgument): user_msg = f"⚠️ Missing argument: `{error.param.name}`. See `{ctx.prefix}help {ctx.command.qualified_name}`."
    elif isinstance(error, (commands.BadArgument, commands.BadUnionArgument, commands.UserInputError)): user_msg = f"⚠️ Invalid argument provided. See `{ctx.prefix}help {ctx.command.qualified_name}`."
    elif isinstance(error, commands.MissingPermissions): user_msg = f"🚫 You lack permissions: `{'`, `'.join(error.missing_permissions)}`."
    elif isinstance(error, commands.BotMissingPermissions): user_msg = f"🚫 I lack permissions: `{'`, `'.join(error.missing_permissions)}`."
    elif isinstance(error, commands.CommandOnCooldown): user_msg = f"⏳ Slow down! This command is on cooldown. Try again in {error.retry_after:.1f}s."
    elif isinstance(error, commands.NotOwner): user_msg = "🚫 This command is for the bot owner only."
    elif isinstance(error, commands.GuildNotFound): user_msg = "⁉️ This command must be used in a server."
    elif isinstance(error, commands.CheckFailure): user_msg = "🚫 You do not meet the requirements to run this command."
    elif isinstance(error, commands.CommandInvokeError):
        user_msg = "🔧 An error occurred while executing the command. The developers have been notified."
        print(f"CommandInvokeError in '{ctx.command.qualified_name}': {error.original}")
        if logging_cog:
            await logging_cog.log_error(ctx.guild, f"Invoke Error: {ctx.command.qualified_name}",
                                        f"Original: `{type(error.original).__name__}: {error.original}`\nInput: `{ctx.message.content}`", 
                                        ctx_or_interaction=ctx, level="CRITICAL") 
            log_err_flag = False 
    else: print(f"Unhandled prefix command error for '{ctx.command.qualified_name if ctx.command else 'N/A'}': {type(error).__name__} - {error}")

    if not isinstance(error, commands.CommandNotFound): 
        try:
            embed = discord.Embed(title="❌ Command Error", description=user_msg, color=discord.Color.orange(), timestamp=datetime.datetime.now(datetime.timezone.utc))
            if ctx.command: embed.set_footer(text=f"Command: {ctx.prefix}{ctx.command.qualified_name}")
            await ctx.send(embed=embed, delete_after=20)
        except Exception as e: print(f"Error sending error embed to user (prefix cmd): {e}")

    if log_err_flag and logging_cog: 
        command_name_for_log = ctx.command.qualified_name if ctx.command else "Unknown Command Invocation"
        error_details_for_log = f"Details: `{type(error).__name__}: {error}`\nInput: `{ctx.message.content if ctx.message else 'No message (possibly error before command resolution)'}`"
        await logging_cog.log_error(ctx.guild, f"Prefix Cmd Error: {command_name_for_log}",
                                    error_details_for_log, 
                                    ctx_or_interaction=ctx)


async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    logging_cog = bot.get_cog("LoggingCog")
    user_msg = "An error occurred with this slash command."
    ephemeral_response = True 

    original_error = getattr(error, 'original', error) 

    if isinstance(original_error, app_commands.CommandNotFound): 
        print(f"Slash command not found: {interaction.data.get('name', 'Unknown')}")
        return 
    elif isinstance(original_error, app_commands.MissingPermissions):
        user_msg = f"🚫 You lack permissions: `{'`, `'.join(original_error.missing_permissions)}`."
    elif isinstance(original_error, app_commands.BotMissingPermissions):
        user_msg = f"🚫 I lack permissions: `{'`, `'.join(original_error.missing_permissions)}`."
    elif isinstance(original_error, app_commands.CommandOnCooldown):
        user_msg = f"⏳ Slow down! This command is on cooldown. Try again in {original_error.retry_after:.1f}s."
    elif isinstance(original_error, app_commands.CheckFailure): 
        user_msg = "🚫 You do not meet the requirements to use this command."
        if hasattr(original_error, 'message') and original_error.message: 
            user_msg = original_error.message
    elif isinstance(original_error, app_commands.TransformerError): 
        param_name = original_error.param.name if hasattr(original_error, 'param') and hasattr(original_error.param, 'name') else 'unknown'
        value_given = original_error.value if hasattr(original_error, 'value') else 'unknown'
        user_msg = f"⚠️ Invalid input for argument '{param_name}': {value_given}"
    elif isinstance(error, app_commands.CommandInvokeError): 
        user_msg = "🔧 An error occurred while executing the command. The developers have been notified."
        command_name = interaction.command.qualified_name if interaction.command else "Unknown"
        print(f"CommandInvokeError in slash command '{command_name}': {error.original}")
        if logging_cog:
            await logging_cog.log_error(interaction.guild, f"Slash Invoke Error: {command_name}",
                                        f"Original: `{type(error.original).__name__}: {error.original}`", 
                                        ctx_or_interaction=interaction, level="CRITICAL") 
    else:
        command_name = interaction.command.qualified_name if interaction.command else "Unknown"
        print(f"Unhandled slash command error for '{command_name}': {type(error).__name__} - {error}")

    try:
        embed = discord.Embed(title="❌ Slash Command Error", description=user_msg, color=discord.Color.red(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        if interaction.command: embed.set_footer(text=f"Command: /{interaction.command.qualified_name}")
        
        if interaction.response.is_done(): 
            await interaction.followup.send(embed=embed, ephemeral=ephemeral_response)
        else:
            await interaction.response.send_message(embed=embed, ephemeral=ephemeral_response)
    except Exception as e:
        print(f"Error sending error embed to user (slash cmd): {e}")
        try:
            if not interaction.response.is_done(): 
                 await interaction.followup.send("An error occurred, and I could not send the detailed error message.", ephemeral=True)
        except: pass

    if logging_cog and not isinstance(error, app_commands.CommandInvokeError): 
        command_name_for_log = interaction.command.qualified_name if interaction.command else "Unknown Slash Command"
        await logging_cog.log_error(interaction.guild, f"Slash Cmd Error: {command_name_for_log}",
                                    f"Details: `{type(error).__name__}: {error}`", 
                                    ctx_or_interaction=interaction) 

# --- MAIN EXECUTION ---
async def main():
    # The setup_hook will run automatically before the bot starts.
    async with bot:
        await bot.start(BOT_TOKEN)

if __name__ == "__main__":
    bot.tree.on_error = on_app_command_error
    try:
        asyncio.run(main())
    except discord.LoginFailure:
        print("CRITICAL ERROR: Login Failure. Invalid BOT_TOKEN.")
    except KeyboardInterrupt:
        print("Bot shutdown.")
    except Exception as e:
        print(f"CRITICAL UNHANDLED ERROR: {e}")