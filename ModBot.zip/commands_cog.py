import discord
from discord.ext import commands
from discord import app_commands
import datetime
import json
import os
from typing import Optional, Union, List
import asyncio # For purge confirmation deletion

# Forward reference for LoggingCog type hint
LoggingCogType = Optional[commands.Cog] 

def load_json_data(filepath: str, default_data=None):
    if default_data is None: default_data = {}
    if not os.path.exists(filepath):
        save_json_data(filepath, default_data)
        return default_data
    try:
        with open(filepath, "r") as f: return json.load(f)
    except (json.JSONDecodeError, IOError):
        print(f"Error reading/decoding {filepath}. Returning default data.")
        return default_data

def save_json_data(filepath: str, data):
    try:
        with open(filepath, "w") as f: json.dump(data, f, indent=4)
    except IOError: print(f"Error writing to {filepath}.")

class CommandsCog(commands.Cog, name="Moderation & Utility"):
    def __init__(self, bot: commands.Bot, warnings_file: str, prefixes_file: str, default_prefix: str):
        self.bot = bot
        self.warnings_file = warnings_file
        self.prefixes_file = prefixes_file
        self.default_prefix = default_prefix
        self.user_warnings = load_json_data(self.warnings_file, {})
        self.server_prefixes = load_json_data(self.prefixes_file, {})
        print("CommandsCog Initialized with separate command decorators.")

    def get_logging_cog(self) -> LoggingCogType:
        return self.bot.get_cog("LoggingCog")

    async def _send_error_embed(self, destination: Union[commands.Context, discord.Interaction], title: str, description: str):
        embed = discord.Embed(title=f"❌ {title}", description=description, color=discord.Color.red(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        if isinstance(destination, discord.Interaction):
            if destination.response.is_done():
                await destination.followup.send(embed=embed, ephemeral=True)
            else:
                await destination.response.send_message(embed=embed, ephemeral=True)
        else: 
            await destination.send(embed=embed, delete_after=20)
            
    async def _send_success_embed(self, destination: Union[commands.Context, discord.Interaction], title: str, description: str, ephemeral: bool = False, public_if_no_interaction: bool = True):
        embed = discord.Embed(title=f" {title}", description=description, color=discord.Color.green(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        if isinstance(destination, discord.Interaction):
            if destination.response.is_done():
                 await destination.followup.send(embed=embed, ephemeral=ephemeral)
            else:
                await destination.response.send_message(embed=embed, ephemeral=ephemeral)
        else: 
            if public_if_no_interaction:
                 await destination.send(embed=embed)
            else: 
                 await destination.send(embed=embed, delete_after=15 if ephemeral else None)

    # --- PING ---
    async def _ping_logic(self, actor: Union[discord.Member, discord.User]):
        latency = round(self.bot.latency * 1000)
        embed = discord.Embed(title="🏓 Pong!", description=f"My current latency is **{latency}ms**.",
                              color=discord.Color.blue(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        embed.set_footer(text=f"Requested by {actor.display_name}", icon_url=actor.display_avatar.url)
        return embed, latency

    @commands.command(name="ping", help="Shows the bot's latency.", description="Shows the bot's latency.")
    async def ping_prefix(self, ctx: commands.Context):
        embed, latency = await self._ping_logic(ctx.author)
        await ctx.send(embed=embed)
        logging_cog = self.get_logging_cog()
        if logging_cog: await logging_cog.log_command_execution(ctx, True, "ping (prefix)", f"Latency: {latency}ms")

    @app_commands.command(name="ping", description="Shows the bot's latency.")
    async def ping_slash(self, interaction: discord.Interaction):
        embed, latency = await self._ping_logic(interaction.user)
        await interaction.response.send_message(embed=embed, ephemeral=True)
        logging_cog = self.get_logging_cog()
        if logging_cog: await logging_cog.log_command_execution(interaction, True, "ping (slash)", f"Latency: {latency}ms")

    # --- PREFIX ---
    async def _prefix_logic(self, guild: discord.Guild, actor: Union[discord.Member, discord.User], new_prefix: Optional[str] = None):
        guild_id_str = str(guild.id)
        if new_prefix:
            if len(new_prefix) > 10:
                return False, "Prefix cannot be longer than 10 characters."
            if " " in new_prefix:
                return False, "Prefix cannot contain spaces."
            
            self.server_prefixes[guild_id_str] = new_prefix
            save_json_data(self.prefixes_file, self.server_prefixes)
            if hasattr(self.bot, 'server_prefixes_cache'): # Update global cache
                self.bot.server_prefixes_cache[guild_id_str] = new_prefix
            return True, f"Server prefix updated to: `{new_prefix}`"
        else:
            current_prefix = self.server_prefixes.get(guild_id_str, self.default_prefix)
            return True, f"Current server prefix: `{current_prefix}`\nDefault global prefix: `{self.default_prefix}`"

    @commands.command(name="prefix", help="Shows or sets the server's command prefix.\nUsage: ?prefix [new_prefix]", description="Shows or sets the server's command prefix.")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def prefix_prefix(self, ctx: commands.Context, *, new_prefix: Optional[str] = None):
        success, message = await self._prefix_logic(ctx.guild, ctx.author, new_prefix)
        logging_cog = self.get_logging_cog()
        if success:
            title = "✅ Prefix Updated" if new_prefix else "ℹ️ Server Prefix"
            await self._send_success_embed(ctx, title, message, ephemeral=True, public_if_no_interaction=False)
            if logging_cog: await logging_cog.log_command_execution(ctx, True, "prefix (prefix)", f"Details: {message}")
        else:
            await self._send_error_embed(ctx, "Prefix Error", message)
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "prefix (prefix)", f"Error: {message}")

    @app_commands.command(name="prefix", description="Shows or sets the server's command prefix.")
    @app_commands.describe(new_prefix="The new prefix (e.g., !, $). Leave blank to view current.")
    @app_commands.checks.has_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def prefix_slash(self, interaction: discord.Interaction, new_prefix: Optional[str] = None):
        success, message = await self._prefix_logic(interaction.guild, interaction.user, new_prefix)
        logging_cog = self.get_logging_cog()
        if success:
            title = "✅ Prefix Updated" if new_prefix else "ℹ️ Server Prefix"
            await self._send_success_embed(interaction, title, message, ephemeral=True)
            if logging_cog: await logging_cog.log_command_execution(interaction, True, "prefix (slash)", f"Details: {message}")
        else:
            await self._send_error_embed(interaction, "Prefix Error", message)
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "prefix (slash)", f"Error: {message}")

    # --- KICK ---
    async def _kick_logic(self, guild: discord.Guild, actor: discord.Member, target_member: discord.Member, reason: str):
        log_details = f"Reason: {reason}"
        if target_member == actor:
            return False, "You cannot kick yourself.", None
        if target_member.id == self.bot.user.id:
            return False, "I cannot kick myself!", None
        # Prevent kicking members with higher or equal roles, unless the actor is the guild owner
        if target_member.top_role >= actor.top_role and actor.id != guild.owner_id:
            return False, "You cannot kick a member with an equal or higher role.", None
        if target_member.top_role >= guild.me.top_role:
             return False, "I cannot kick this member because they have a higher or equal role than me.", None

        # --- MODIFICATION START ---
        # Only attempt to DM the member if they are not a bot.
        if not target_member.bot:
            dm_embed = discord.Embed(
                title=f"👢 Kicked from {guild.name}",
                description=f"**Reason:** {reason}",
                color=discord.Color.orange(),
                timestamp=datetime.datetime.now(datetime.timezone.utc)
            )
            try:
                await target_member.send(embed=dm_embed)
            except (discord.Forbidden, discord.HTTPException):
                # Catches errors if the user has DMs closed or if they are a bot (belt-and-suspenders).
                log_details += " (Could not DM user)"
        # --- MODIFICATION END ---

        await target_member.kick(reason=f"Kicked by {actor.display_name} ({actor.id}). Reason: {reason}")
        
        confirm_embed = discord.Embed(
            title="👢 Member Kicked",
            description=f"**{target_member.display_name}** (`{target_member.id}`) has been kicked.",
            color=discord.Color.red(),
            timestamp=datetime.datetime.now(datetime.timezone.utc)
        )
        confirm_embed.add_field(name="Reason", value=reason, inline=False)
        confirm_embed.set_footer(text=f"Kicked by {actor.display_name}")
        return True, confirm_embed, log_details

    @commands.command(name="kick", help="Kicks a member.\nUsage: ?kick <@member> [reason]", description="Kicks a member from the server.")
    @commands.has_permissions(kick_members=True)
    @commands.bot_has_permissions(kick_members=True)
    @commands.guild_only()
    async def kick_prefix(self, ctx: commands.Context, member: discord.Member, *, reason: str = "No reason provided"):
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._kick_logic(ctx.guild, ctx.author, member, reason)
            if success:
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "kick (prefix)", log_details, target=member)
            else:
                await self._send_error_embed(ctx, "Kick Error", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "kick (prefix)", response, target=member)
        except discord.Forbidden:
            await self._send_error_embed(ctx, "Permission Error", "I do not have permission to kick this member. My role might be too low.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "kick (prefix)", "Bot lacked kick permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(ctx, "Kick Error", f"An unexpected error occurred: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Kick (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="kick", description="Kicks a member from the server.")
    @app_commands.describe(member="The member to kick.", reason="The reason for kicking.")
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.checks.bot_has_permissions(kick_members=True) # Ensure bot has perms for slash commands too
    @app_commands.guild_only()
    async def kick_slash(self, interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = None):
        # Reason can be None in slash commands, provide a default
        actual_reason = reason or "No reason provided"
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._kick_logic(interaction.guild, interaction.user, member, actual_reason)
            if success:
                await interaction.response.send_message(embed=response, ephemeral=False)
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "kick (slash)", log_details, target=member)
            else:
                await self._send_error_embed(interaction, "Kick Error", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "kick (slash)", response, target=member)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", "I do not have permission to kick this member. My role might be too low.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "kick (slash)", "Bot lacked kick permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(interaction, "Kick Error", f"An unexpected error occurred: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Kick (slash) Error", str(e), ctx_or_interaction=interaction)

    # --- BAN ---
    async def _ban_logic(self, guild: discord.Guild, actor: discord.Member, target_user: Union[discord.Member, discord.User], delete_days: int, reason: str):
        log_details = f"Reason: {reason}, Delete message days: {delete_days}"
        if target_user.id == actor.id: return False, "You cannot ban yourself.", None
        if target_user.id == self.bot.user.id: return False, "I cannot ban myself!", None
        if isinstance(target_user, discord.Member) and target_user.top_role >= actor.top_role and actor != guild.owner:
            return False, "You cannot ban a member with an equal or higher role.", None

        dm_embed = discord.Embed(title=f"🔨 Banned from {guild.name}", description=f"**Reason:** {reason}", color=discord.Color.dark_red(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        if isinstance(target_user, discord.Member):
            try: await target_user.send(embed=dm_embed)
            except discord.Forbidden: log_details += " (Could not DM user)"
        
        await guild.ban(target_user, reason=f"Banned by {actor} ({actor.id}). Reason: {reason}", delete_message_days=delete_days)
        
        user_display = target_user.display_name if isinstance(target_user, discord.Member) else target_user.name
        confirm_embed = discord.Embed(title="🔨 User Banned", description=f"**{user_display}** (`{target_user.id}`) has been banned.", color=discord.Color.dark_red(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        confirm_embed.add_field(name="Reason", value=reason, inline=False)
        confirm_embed.set_footer(text=f"Banned by {actor.display_name}")
        return True, confirm_embed, log_details

    @commands.command(name="ban", help="Bans a user.\nUsage: ?ban <@user_or_ID> [delete_days=0] [reason]", description="Bans a user from the server.")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    @commands.guild_only()
    async def ban_prefix(self, ctx: commands.Context, user: Union[discord.Member, discord.User], delete_days: Optional[int] = 0, *, reason: str = "No reason provided"):
        logging_cog = self.get_logging_cog()
        if not (0 <= delete_days <= 7): # type: ignore
            await self._send_error_embed(ctx, "Input Error", "Delete message days must be between 0 and 7.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "ban (prefix)", "Invalid delete_days.", target=user)
            return
        try:
            success, response, log_details = await self._ban_logic(ctx.guild, ctx.author, user, delete_days, reason) # type: ignore
            if success:
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "ban (prefix)", log_details, target=user)
            else:
                await self._send_error_embed(ctx, "Ban Error", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "ban (prefix)", response, target=user)
        except discord.Forbidden:
            await self._send_error_embed(ctx, "Permission Error", "I do not have permission to ban. My role might be too low.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "ban (prefix)", "Bot lacked ban permissions.", target=user)
        except Exception as e:
            await self._send_error_embed(ctx, "Ban Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Ban (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="ban", description="Bans a user from the server.")
    @app_commands.describe(user="The user to ban.", delete_message_days="Days of messages to delete (0-7).", reason="Reason for ban.")
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.guild_only()
    async def ban_slash(self, interaction: discord.Interaction, user: Union[discord.Member, discord.User], delete_message_days: Optional[app_commands.Range[int, 0, 7]] = 0, reason: Optional[str] = "No reason provided"):
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._ban_logic(interaction.guild, interaction.user, user, delete_message_days or 0, reason or "No reason provided")
            if success:
                await interaction.response.send_message(embed=response, ephemeral=False)
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "ban (slash)", log_details, target=user)
            else:
                await self._send_error_embed(interaction, "Ban Error", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "ban (slash)", response, target=user)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", "I do not have permission to ban. My role might be too low.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "ban (slash)", "Bot lacked ban permissions.", target=user)
        except Exception as e:
            await self._send_error_embed(interaction, "Ban Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Ban (slash) Error", str(e), ctx_or_interaction=interaction)

    # --- UNBAN ---
    async def _unban_logic(self, guild: discord.Guild, actor: discord.Member, user_id_str: str, reason: str):
        target_user: Optional[discord.User] = None
        try:
            uid = int(user_id_str)
            target_user = await self.bot.fetch_user(uid)
        except ValueError: return False, "Invalid User ID format. Please provide a numerical ID.", None
        except discord.NotFound: return False, f"User with ID `{user_id_str}` not found on Discord.", None

        try:
            await guild.fetch_ban(target_user)
        except discord.NotFound: return False, f"User **{target_user}** (`{target_user.id}`) is not currently banned.", None
        
        await guild.unban(target_user, reason=f"Unbanned by {actor} ({actor.id}). Reason: {reason}")
        confirm_embed = discord.Embed(title="🕊️ User Unbanned", description=f"**{target_user}** (`{target_user.id}`) has been unbanned.", color=discord.Color.green(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        confirm_embed.add_field(name="Reason", value=reason, inline=False)
        confirm_embed.set_footer(text=f"Unbanned by {actor.display_name}")
        return True, confirm_embed, f"Reason: {reason}"

    @commands.command(name="unban", help="Unbans a user by ID.\nUsage: ?unban <user_ID> [reason]", description="Unbans a user from the server.")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    @commands.guild_only()
    async def unban_prefix(self, ctx: commands.Context, user_id: str, *, reason: str = "No reason provided"):
        logging_cog = self.get_logging_cog()
        target_user_for_log = user_id 
        try:
            success, response, log_details = await self._unban_logic(ctx.guild, ctx.author, user_id, reason)
            if success: 
                await ctx.send(embed=response)
                try: fetched_user = await self.bot.fetch_user(int(user_id))
                except: fetched_user = user_id 
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "unban (prefix)", log_details, target=fetched_user)
            else: 
                await self._send_error_embed(ctx, "Unban Error", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "unban (prefix)", response, target=target_user_for_log)
        except discord.Forbidden:
            await self._send_error_embed(ctx, "Permission Error", "I do not have permission to unban users.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "unban (prefix)", "Bot lacked unban permissions.", target=target_user_for_log)
        except Exception as e:
            await self._send_error_embed(ctx, "Unban Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Unban (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="unban", description="Unbans a user from the server using their ID.")
    @app_commands.describe(user_id="The ID of the user to unban.", reason="The reason for unbanning.")
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.guild_only()
    async def unban_slash(self, interaction: discord.Interaction, user_id: str, reason: Optional[str] = "No reason provided"):
        logging_cog = self.get_logging_cog()
        target_user_for_log = user_id
        try:
            success, response, log_details = await self._unban_logic(interaction.guild, interaction.user, user_id, reason or "No reason provided")
            if success: 
                await interaction.response.send_message(embed=response, ephemeral=False)
                try: fetched_user = await self.bot.fetch_user(int(user_id))
                except: fetched_user = user_id
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "unban (slash)", log_details, target=fetched_user)
            else: 
                await self._send_error_embed(interaction, "Unban Error", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "unban (slash)", response, target=target_user_for_log)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", "I do not have permission to unban users.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "unban (slash)", "Bot lacked unban permissions.", target=target_user_for_log)
        except Exception as e:
            await self._send_error_embed(interaction, "Unban Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Unban (slash) Error", str(e), ctx_or_interaction=interaction)

    # --- WARN ---
    async def _warn_logic(self, guild: discord.Guild, actor: discord.Member, target_member: discord.Member, reason: str):
        if target_member == actor: return False, "You cannot warn yourself.", None, -1
        if target_member.bot: return False, "You cannot warn bots.", None, -1
        if target_member.top_role >= actor.top_role and actor != guild.owner:
            return False, "You cannot warn a member with an equal or higher role.", None, -1

        gid_str, mid_str = str(guild.id), str(target_member.id)
        self.user_warnings.setdefault(gid_str, {}).setdefault(mid_str, [])
        warn_id = max((w['id'] for w in self.user_warnings[gid_str][mid_str]), default=0) + 1
        
        warn_entry = { "id": warn_id, "reason": reason, "moderator_id": actor.id, 
                       "moderator_name": str(actor), "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat() }
        self.user_warnings[gid_str][mid_str].append(warn_entry)
        save_json_data(self.warnings_file, self.user_warnings)

        confirm_embed = discord.Embed(title="⚠️ Member Warned", description=f"**{target_member.mention}** has been warned.", color=discord.Color.gold(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        confirm_embed.add_field(name="Reason", value=reason, inline=False).add_field(name="Warning ID", value=str(warn_id), inline=True)
        confirm_embed.set_footer(text=f"Warned by {actor.display_name}")
        
        log_details = f"Reason: {reason}, ID: {warn_id}"
        try:
            dm_embed = discord.Embed(title=f"⚠️ You have been warned in {guild.name}", color=discord.Color.gold(), timestamp=datetime.datetime.fromisoformat(warn_entry["timestamp"]))
            dm_embed.add_field(name="Reason", value=reason, inline=False).add_field(name="Moderator", value=actor.mention, inline=True).add_field(name="Warning ID", value=str(warn_id), inline=True)
            await target_member.send(embed=dm_embed)
        except discord.Forbidden: log_details += " (Could not DM user)"
        return True, confirm_embed, log_details, warn_id

    @commands.command(name="warn", help="Warns a member.\nUsage: ?warn <@member> <reason>", description="Warns a member on the server.")
    @commands.has_permissions(kick_members=True) 
    @commands.guild_only()
    async def warn_prefix(self, ctx: commands.Context, member: discord.Member, *, reason: str):
        logging_cog = self.get_logging_cog()
        success, response, log_details, _ = await self._warn_logic(ctx.guild, ctx.author, member, reason)
        if success: 
            await ctx.send(embed=response)
            if logging_cog: await logging_cog.log_command_execution(ctx, True, "warn (prefix)", log_details, target=member)
        else: 
            await self._send_error_embed(ctx, "Warn Error", response)
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "warn (prefix)", response, target=member)

    @app_commands.command(name="warn", description="Warns a member on the server.")
    @app_commands.describe(member="The member to warn.", reason="The reason for the warning.")
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.guild_only()
    async def warn_slash(self, interaction: discord.Interaction, member: discord.Member, reason: str):
        logging_cog = self.get_logging_cog()
        success, response, log_details, _ = await self._warn_logic(interaction.guild, interaction.user, member, reason)
        if success: 
            await interaction.response.send_message(embed=response, ephemeral=False) 
            if logging_cog: await logging_cog.log_command_execution(interaction, True, "warn (slash)", log_details, target=member)
        else: 
            await self._send_error_embed(interaction, "Warn Error", response)
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "warn (slash)", response, target=member)

    # --- WARNINGS ---
    async def _warnings_logic(self, guild: discord.Guild, target_member: discord.Member):
        gid_str, mid_str = str(guild.id), str(target_member.id)
        member_warns = self.user_warnings.get(gid_str, {}).get(mid_str, [])
        
        if not member_warns:
            embed = discord.Embed(title=f"📜 Warnings for {target_member.display_name}", description="This member has no warnings on record.", color=discord.Color.green(), timestamp=datetime.datetime.now(datetime.timezone.utc))
            return True, embed, "No warnings found."

        embed = discord.Embed(title=f"📜 Warnings for {target_member.display_name}", color=discord.Color.orange(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        if target_member.display_avatar: embed.set_thumbnail(url=target_member.display_avatar.url)
        
        description_text = ""
        for warn_entry in sorted(member_warns, key=lambda w: w['id']):
            mod_name = warn_entry.get('moderator_name', 'Unknown Moderator')
            ts_str = warn_entry.get('timestamp')
            ts_formatted = datetime.datetime.fromisoformat(ts_str).strftime("%Y-%m-%d %H:%M UTC") if ts_str else "Unknown Time"
            description_text += f"**ID: {warn_entry['id']}** | By: {mod_name}\nReason: `{warn_entry['reason']}`\n*At: {ts_formatted}*\n---\n"
        
        if len(description_text) > 3900 : description_text = description_text[:3900] + "\n...(list truncated)..."
        embed.description = description_text
        embed.set_footer(text=f"Total warnings: {len(member_warns)}")
        return True, embed, f"{len(member_warns)} warnings displayed."

    @commands.command(name="warnings", aliases=["warns"], help="Shows warnings for a member.\nUsage: ?warnings <@member>", description="Shows warnings for a member.")
    @commands.has_permissions(kick_members=True) 
    @commands.guild_only()
    async def warnings_prefix(self, ctx: commands.Context, member: discord.Member):
        logging_cog = self.get_logging_cog()
        success, response_embed, log_details = await self._warnings_logic(ctx.guild, member)
        await ctx.send(embed=response_embed) 
        if logging_cog: await logging_cog.log_command_execution(ctx, success, "warnings (prefix)", log_details, target=member)

    @app_commands.command(name="warnings", description="Shows warnings for a member.")
    @app_commands.describe(member="The member whose warnings to view.")
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.guild_only()
    async def warnings_slash(self, interaction: discord.Interaction, member: discord.Member):
        logging_cog = self.get_logging_cog()
        success, response_embed, log_details = await self._warnings_logic(interaction.guild, member)
        await interaction.response.send_message(embed=response_embed, ephemeral=True) 
        if logging_cog: await logging_cog.log_command_execution(interaction, success, "warnings (slash)", log_details, target=member)

    # --- UNWARN ---
    async def _unwarn_logic(self, guild: discord.Guild, actor: discord.Member, target_member: discord.Member, warning_id: int):
        gid_str, mid_str = str(guild.id), str(target_member.id)

        if not self.user_warnings.get(gid_str, {}).get(mid_str, []):
            return False, f"{target_member.mention} has no warnings to remove.", None
        
        removed_warning = None
        warns_list = self.user_warnings[gid_str][mid_str]
        for i, warn_entry in enumerate(warns_list):
            if warn_entry["id"] == warning_id:
                removed_warning = warns_list.pop(i)
                break
        
        if removed_warning:
            save_json_data(self.warnings_file, self.user_warnings)
            confirm_embed = discord.Embed(title="🗑️ Warning Removed", description=f"Warning ID `{warning_id}` (Reason: `{removed_warning['reason']}`) has been removed for **{target_member.mention}**.", color=discord.Color.green(), timestamp=datetime.datetime.now(datetime.timezone.utc))
            confirm_embed.set_footer(text=f"Warning removed by {actor.display_name}")
            return True, confirm_embed, f"Removed ID {warning_id}, Reason: {removed_warning['reason']}"
        else:
            return False, f"Warning ID `{warning_id}` not found for {target_member.mention}.", None

    @commands.command(name="unwarn", help="Removes a specific warning.\nUsage: ?unwarn <@member> <warning_id>", description="Removes a specific warning from a member.")
    @commands.has_permissions(manage_messages=True) 
    @commands.guild_only()
    async def unwarn_prefix(self, ctx: commands.Context, member: discord.Member, warning_id: int):
        logging_cog = self.get_logging_cog()
        try: 
            success, response, log_details = await self._unwarn_logic(ctx.guild, ctx.author, member, warning_id)
            if success: 
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "unwarn (prefix)", log_details, target=member)
            else: 
                await self._send_error_embed(ctx, "Unwarn Error", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "unwarn (prefix)", response, target=member)
        except ValueError: 
            await self._send_error_embed(ctx, "Input Error", "Warning ID must be a number.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "unwarn (prefix)", "Invalid Warning ID (not a number).", target=member)

    @app_commands.command(name="unwarn", description="Removes a specific warning from a member.")
    @app_commands.describe(member="The member whose warning to remove.", warning_id="The ID of the warning to remove.")
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.guild_only()
    async def unwarn_slash(self, interaction: discord.Interaction, member: discord.Member, warning_id: int): 
        logging_cog = self.get_logging_cog()
        success, response, log_details = await self._unwarn_logic(interaction.guild, interaction.user, member, warning_id)
        if success: 
            await interaction.response.send_message(embed=response, ephemeral=False) 
            if logging_cog: await logging_cog.log_command_execution(interaction, True, "unwarn (slash)", log_details, target=member)
        else: 
            await self._send_error_embed(interaction, "Unwarn Error", response)
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "unwarn (slash)", response, target=member)

    # --- PURGE (Example structure, ensure this matches your v6_en) ---
    async def _purge_logic(self, channel: discord.TextChannel, actor: Union[discord.Member, discord.User], amount: int, target_member: Optional[discord.Member]):
        check_func = (lambda m: m.author == target_member) if target_member else (lambda m: True)
        # For slash commands, interaction.channel might not be TextChannel if command is allowed elsewhere.
        # Ensure channel is TextChannel before calling purge.
        if not isinstance(channel, discord.TextChannel):
            return False, "Purge can only be used in text channels.", None, 0

        deleted_messages = await channel.purge(limit=amount, check=check_func) 

        desc = f"Successfully deleted **{len(deleted_messages)}** message(s)"
        if target_member: desc += f" from {target_member.mention}"
        desc += f" in {channel.mention}."
        
        confirm_embed = discord.Embed(title="🗑️ Messages Purged", description=desc, color=discord.Color.teal(), timestamp=datetime.datetime.now(datetime.timezone.utc))
        if hasattr(actor, 'display_name'): # actor might be discord.User for interactions if member intent is off
            confirm_embed.set_footer(text=f"Action by {actor.display_name}")
        else:
            confirm_embed.set_footer(text=f"Action by {str(actor)}")

        
        log_details = f"Amount requested: {amount}."
        if target_member: log_details += f" Target Member: {target_member.mention}"
        return True, confirm_embed, log_details, len(deleted_messages)

    @commands.command(name="purge", aliases=["clear", "prune"], help="Deletes messages.\nUsage: ?purge <amount> [@member (optional)]", description="Deletes a specified number of messages.")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def purge_prefix(self, ctx: commands.Context, amount: int, member: Optional[discord.Member] = None):
        logging_cog = self.get_logging_cog()
        if not (1 <= amount <= 100):
            await self._send_error_embed(ctx, "Input Error", "Amount must be between 1 and 100.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "purge (prefix)", f"Invalid amount: {amount}.")
            return
        
        if not isinstance(ctx.channel, discord.TextChannel):
            await self._send_error_embed(ctx, "Channel Error", "Purge can only be used in text channels.")
            return

        try: await ctx.message.delete() 
        except discord.HTTPException: pass

        success, response_embed, log_details, num_deleted = await self._purge_logic(ctx.channel, ctx.author, amount, member)
        if success:
            msg = await ctx.send(embed=response_embed)
            await asyncio.sleep(10) 
            try: await msg.delete() 
            except discord.HTTPException: pass
            if logging_cog: await logging_cog.log_command_execution(ctx, True, "purge (prefix)", f"{log_details} ({num_deleted} actually deleted)", target=ctx.channel)
        else: # response_embed here is actually an error message string from _purge_logic if it returns False early
            await self._send_error_embed(ctx, "Purge Error", response_embed) # type: ignore
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "purge (prefix)", response_embed, target=ctx.channel) # type: ignore


    @app_commands.command(name="purge", description="Deletes a specified number of messages.")
    @app_commands.describe(amount="Number of messages to delete (1-100).", member="Optional: Delete messages only from this member.")
    @app_commands.checks.has_permissions(manage_messages=True) # For slash commands
    @app_commands.guild_only()
    async def purge_slash(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100], member: Optional[discord.Member] = None):
        logging_cog = self.get_logging_cog()
        
        # Ensure interaction.channel is a TextChannel for purge
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message(embed=discord.Embed(title="❌ Channel Error", description="Purge can only be used in text channels.", color=discord.Color.red()), ephemeral=True)
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "purge (slash)", "Used in non-text channel.", target=interaction.channel)
            return

        await interaction.response.defer(ephemeral=True) 

        success, response_embed, log_details, num_deleted = await self._purge_logic(interaction.channel, interaction.user, amount, member)
        
        if success:
            await interaction.followup.send(embed=response_embed, ephemeral=True) 
            if logging_cog: await logging_cog.log_command_execution(interaction, True, "purge (slash)", f"{log_details} ({num_deleted} actually deleted)", target=interaction.channel)
        else: # response_embed here is an error message string
            error_embed = discord.Embed(title="❌ Purge Error", description=response_embed, color=discord.Color.red()) # type: ignore
            await interaction.followup.send(embed=error_embed, ephemeral=True)
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "purge (slash)", response_embed, target=interaction.channel) # type: ignore

    # --- LOCK & UNLOCK ---
    async def _lock_logic(self, channel: discord.TextChannel, actor: discord.Member, reason: str, lock_action: bool):
        overwrite = channel.overwrites_for(channel.guild.default_role)
        action_str = "locked" if lock_action else "unlocked"
        current_state_locked = overwrite.send_messages is False

        if lock_action and current_state_locked:
            return False, f"{channel.mention} is already {action_str}.", None
        if not lock_action and not current_state_locked:
            return False, f"{channel.mention} is not {action_str} or already allows messages.", None

        overwrite.send_messages = False if lock_action else None 
        await channel.set_permissions(channel.guild.default_role, overwrite=overwrite, reason=f"Channel {action_str} by {actor}. Reason: {reason}")
        
        title = f"🔒 Channel {action_str.capitalize()}" if lock_action else f"🔓 Channel {action_str.capitalize()}"
        color = discord.Color.red() if lock_action else discord.Color.green()
        confirm_embed = discord.Embed(title=title, description=f"{channel.mention} has been {action_str}.", color=color, timestamp=datetime.datetime.now(datetime.timezone.utc))
        confirm_embed.add_field(name="Reason", value=reason).set_footer(text=f"Action by {actor.display_name}")
        return True, confirm_embed, f"Reason: {reason}"

    @commands.command(name="lock", help="Locks the current channel.\nUsage: ?lock [reason]", description="Locks the current channel.")
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def lock_prefix(self, ctx: commands.Context, *, reason: str = "No reason provided"):
        logging_cog = self.get_logging_cog()
        if not isinstance(ctx.channel, discord.TextChannel):
            await self._send_error_embed(ctx, "Channel Error", "This command can only be used in text channels.")
            return
        try:
            success, response, log_details = await self._lock_logic(ctx.channel, ctx.author, reason, True)
            if success:
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "lock (prefix)", log_details, target=ctx.channel)
            else:
                await self._send_error_embed(ctx, "Lock Info", response) 
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "lock (prefix)", response, target=ctx.channel)
        except discord.Forbidden:
            await self._send_error_embed(ctx, "Permission Error", "I do not have permission to manage this channel.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "lock (prefix)", "Bot lacked channel permissions.", target=ctx.channel)
        except Exception as e:
            await self._send_error_embed(ctx, "Lock Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Lock (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="lock", description="Locks the current channel.")
    @app_commands.describe(reason="Reason for locking the channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.guild_only()
    async def lock_slash(self, interaction: discord.Interaction, reason: Optional[str] = "No reason provided"):
        logging_cog = self.get_logging_cog()
        if not isinstance(interaction.channel, discord.TextChannel): 
            await self._send_error_embed(interaction, "Channel Error", "This command can only be used in text channels.")
            return
        try:
            success, response, log_details = await self._lock_logic(interaction.channel, interaction.user, reason or "No reason provided", True) # type: ignore
            if success:
                await interaction.response.send_message(embed=response, ephemeral=False) 
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "lock (slash)", log_details, target=interaction.channel)
            else:
                await self._send_error_embed(interaction, "Lock Info", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "lock (slash)", response, target=interaction.channel)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", "I do not have permission to manage this channel.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "lock (slash)", "Bot lacked channel permissions.", target=interaction.channel)
        except Exception as e:
            await self._send_error_embed(interaction, "Lock Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Lock (slash) Error", str(e), ctx_or_interaction=interaction)

    @commands.command(name="unlock", help="Unlocks the current channel.\nUsage: ?unlock [reason]", description="Unlocks the current channel.")
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def unlock_prefix(self, ctx: commands.Context, *, reason: str = "No reason provided"):
        logging_cog = self.get_logging_cog()
        if not isinstance(ctx.channel, discord.TextChannel):
            await self._send_error_embed(ctx, "Channel Error", "This command can only be used in text channels.")
            return
        try:
            success, response, log_details = await self._lock_logic(ctx.channel, ctx.author, reason, False) 
            if success:
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "unlock (prefix)", log_details, target=ctx.channel)
            else:
                await self._send_error_embed(ctx, "Unlock Info", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "unlock (prefix)", response, target=ctx.channel)
        except discord.Forbidden:
            await self._send_error_embed(ctx, "Permission Error", "I do not have permission to manage this channel.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "unlock (prefix)", "Bot lacked channel permissions.", target=ctx.channel)
        except Exception as e:
            await self._send_error_embed(ctx, "Unlock Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Unlock (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="unlock", description="Unlocks the current channel.")
    @app_commands.describe(reason="Reason for unlocking the channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.guild_only()
    async def unlock_slash(self, interaction: discord.Interaction, reason: Optional[str] = "No reason provided"):
        logging_cog = self.get_logging_cog()
        if not isinstance(interaction.channel, discord.TextChannel):
            await self._send_error_embed(interaction, "Channel Error", "This command can only be used in text channels.")
            return
        try:
            success, response, log_details = await self._lock_logic(interaction.channel, interaction.user, reason or "No reason provided", False) # type: ignore
            if success:
                await interaction.response.send_message(embed=response, ephemeral=False)
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "unlock (slash)", log_details, target=interaction.channel)
            else:
                await self._send_error_embed(interaction, "Unlock Info", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "unlock (slash)", response, target=interaction.channel)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", "I do not have permission to manage this channel.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "unlock (slash)", "Bot lacked channel permissions.", target=interaction.channel)
        except Exception as e:
            await self._send_error_embed(interaction, "Unlock Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Unlock (slash) Error", str(e), ctx_or_interaction=interaction)

    # --- MUTE & UNMUTE ---
    async def _role_based_mute_logic(self, guild: discord.Guild, actor: discord.Member, target_member: discord.Member, reason: str, mute_action: bool):
        if target_member == actor: return False, f"You cannot {'mute' if mute_action else 'unmute'} yourself.", None
        if target_member.id == self.bot.user.id: return False, f"I cannot {'mute' if mute_action else 'unmute'} myself!", None
        if target_member.top_role >= actor.top_role and actor != guild.owner:
            return False, f"You cannot {'mute' if mute_action else 'unmute'} a member with an equal or higher role.", None

        muted_role = discord.utils.find(lambda r: r.name.lower() == "muted 🔇", guild.roles)
        if not muted_role:
            return False, "A 'Muted' role was not found. Please create one and configure its permissions.", None
        
        action_str = "mute" if mute_action else "unmute"
        action_str_past = "muted" if mute_action else "unmuted"
        color = discord.Color.light_grey() if mute_action else discord.Color.green()
        title_emoji = "🔇" if mute_action else "🔊"

        if mute_action: 
            if muted_role in target_member.roles:
                return False, f"{target_member.mention} is already muted.", None
            await target_member.add_roles(muted_role, reason=f"{action_str_past.capitalize()} by {actor}. Reason: {reason}")
        else: 
            if muted_role not in target_member.roles:
                return False, f"{target_member.mention} is not muted with the 'Muted' role.", None
            await target_member.remove_roles(muted_role, reason=f"{action_str_past.capitalize()} by {actor}. Reason: {reason}")

        confirm_embed = discord.Embed(title=f"{title_emoji} Member {action_str_past.capitalize()}", description=f"**{target_member.mention}** has been {action_str_past}.", color=color, timestamp=datetime.datetime.now(datetime.timezone.utc))
        confirm_embed.add_field(name="Reason", value=reason).set_footer(text=f"Action by {actor.display_name}")
        
        log_details = f"Reason: {reason}"
        try:
            dm_embed = discord.Embed(title=f"{title_emoji} You have been {action_str_past} in {guild.name}", description=f"**Reason:** {reason}", color=color, timestamp=datetime.datetime.now(datetime.timezone.utc))
            await target_member.send(embed=dm_embed)
        except discord.Forbidden: log_details += " (Could not DM user)"
        return True, confirm_embed, log_details

    @commands.command(name="mute", help="Mutes a member (requires 'Muted' role).\nUsage: ?mute <@member> [reason]", description="Mutes a member.")
    @commands.has_permissions(manage_roles=True, moderate_members=True)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.guild_only()
    async def mute_prefix(self, ctx: commands.Context, member: discord.Member, *, reason: str = "No reason provided"):
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._role_based_mute_logic(ctx.guild, ctx.author, member, reason, True)
            if success:
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "mute (prefix)", log_details, target=member)
            else:
                await self._send_error_embed(ctx, "Mute Error", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "mute (prefix)", response, target=member)
        except discord.Forbidden: 
            await self._send_error_embed(ctx, "Permission Error", "I do not have permission to assign the 'Muted' role. My role might be below it.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "mute (prefix)", "Bot lacked role assignment permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(ctx, "Mute Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Mute (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="mute", description="Mutes a member (requires a configured 'Muted' role).")
    @app_commands.describe(member="The member to mute.", reason="Reason for muting.")
    @app_commands.checks.has_permissions(manage_roles=True, moderate_members=True)
    @app_commands.guild_only()
    async def mute_slash(self, interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._role_based_mute_logic(interaction.guild, interaction.user, member, reason or "No reason provided", True)
            if success:
                await interaction.response.send_message(embed=response, ephemeral=False) 
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "mute (slash)", log_details, target=member)
            else:
                await self._send_error_embed(interaction, "Mute Error", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "mute (slash)", response, target=member)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", "I do not have permission to assign the 'Muted' role. My role might be below it.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "mute (slash)", "Bot lacked role assignment permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(interaction, "Mute Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Mute (slash) Error", str(e), ctx_or_interaction=interaction)

    @commands.command(name="unmute", help="Unmutes a member.\nUsage: ?unmute <@member> [reason]", description="Unmutes a member.")
    @commands.has_permissions(manage_roles=True, moderate_members=True)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.guild_only()
    async def unmute_prefix(self, ctx: commands.Context, member: discord.Member, *, reason: str = "No reason provided"):
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._role_based_mute_logic(ctx.guild, ctx.author, member, reason, False) 
            if success:
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "unmute (prefix)", log_details, target=member)
            else:
                await self._send_error_embed(ctx, "Unmute Error", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "unmute (prefix)", response, target=member)
        except discord.Forbidden:
            await self._send_error_embed(ctx, "Permission Error", "I do not have permission to remove the 'Muted' role.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "unmute (prefix)", "Bot lacked role removal permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(ctx, "Unmute Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Unmute (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="unmute", description="Unmutes a member.")
    @app_commands.describe(member="The member to unmute.", reason="Reason for unmuting.")
    @app_commands.checks.has_permissions(manage_roles=True, moderate_members=True)
    @app_commands.guild_only()
    async def unmute_slash(self, interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._role_based_mute_logic(interaction.guild, interaction.user, member, reason or "No reason provided", False)
            if success:
                await interaction.response.send_message(embed=response, ephemeral=False)
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "unmute (slash)", log_details, target=member)
            else:
                await self._send_error_embed(interaction, "Unmute Error", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "unmute (slash)", response, target=member)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", "I do not have permission to remove the 'Muted' role.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "unmute (slash)", "Bot lacked role removal permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(interaction, "Unmute Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Unmute (slash) Error", str(e), ctx_or_interaction=interaction)

    # --- ROLE ---
    async def _role_logic(self, guild: discord.Guild, actor: discord.Member, target_member: discord.Member, action: str, target_role: discord.Role):
        action_lower = action.lower()
        if action_lower not in ["add", "remove"]:
            return False, "Invalid action. Use 'add' or 'remove'.", None
        
        if target_role >= actor.top_role and actor != guild.owner:
            return False, f"You cannot manage the role `{target_role.name}` as it's higher than or equal to your highest role.", None
        if target_role >= guild.me.top_role:
            return False, f"I cannot manage the role `{target_role.name}` as it's higher than or equal to my highest role.", None
        if target_role.is_default() or target_role.is_integration() or target_role.is_bot_managed():
             return False, f"Cannot manage the role `{target_role.name}` (default, integration, or bot-managed role).", None

        action_str_ger = "added" if action_lower == "add" else "removed"
        title_emoji = "➕" if action_lower == "add" else "➖"
        color = discord.Color.green() if action_lower == "add" else discord.Color.orange()

        if action_lower == "add":
            if target_role in target_member.roles:
                return False, f"{target_member.mention} already has the role `{target_role.name}`.", None
            await target_member.add_roles(target_role, reason=f"Role {action_str_ger} by {actor}")
        else: # remove
            if target_role not in target_member.roles:
                return False, f"{target_member.mention} does not have the role `{target_role.name}`.", None
            await target_member.remove_roles(target_role, reason=f"Role {action_str_ger} by {actor}")

        confirm_embed = discord.Embed(title=f"{title_emoji} Role {action_str_ger.capitalize()}", description=f"Role `{target_role.name}` was {action_str_ger} for **{target_member.mention}**.", color=color, timestamp=datetime.datetime.now(datetime.timezone.utc))
        confirm_embed.set_footer(text=f"Action by {actor.display_name}")
        return True, confirm_embed, f"Action: {action_lower}, Role: {target_role.name}"

    @commands.command(name="role", aliases=["roles"], help="Adds or removes a role from a member.\nUsage: ?role <@member> <add|remove> <role_name_or_id>", description="Adds or removes a role from a member.")
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.guild_only()
    async def role_prefix(self, ctx: commands.Context, member: discord.Member, action: str, *, role: discord.Role): 
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._role_logic(ctx.guild, ctx.author, member, action, role)
            if success: 
                await ctx.send(embed=response)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "role (prefix)", log_details, target=member)
            else: 
                await self._send_error_embed(ctx, "Role Error", response)
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "role (prefix)", response, target=member)
        except discord.Forbidden: 
            await self._send_error_embed(ctx, "Permission Error", f"I do not have permission to manage the role `{role.name}` for this member.")
            if logging_cog: await logging_cog.log_command_execution(ctx, False, "role (prefix)", "Bot lacked role management permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(ctx, "Role Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(ctx.guild, "Role (prefix) Error", str(e), ctx_or_interaction=ctx)

    @app_commands.command(name="role", description="Adds or removes a role from a member.")
    @app_commands.describe(member="The member to modify.", action="Action: 'add' or 'remove'.", role="The role to add/remove.")
    @app_commands.choices(action=[ 
        app_commands.Choice(name="Add", value="add"),
        app_commands.Choice(name="Remove", value="remove")
    ])
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.guild_only()
    async def role_slash(self, interaction: discord.Interaction, member: discord.Member, action: app_commands.Choice[str], role: discord.Role):
        logging_cog = self.get_logging_cog()
        try:
            success, response, log_details = await self._role_logic(interaction.guild, interaction.user, member, action.value, role)
            if success: 
                await interaction.response.send_message(embed=response, ephemeral=False) 
                if logging_cog: await logging_cog.log_command_execution(interaction, True, "role (slash)", log_details, target=member)
            else: 
                await self._send_error_embed(interaction, "Role Error", response)
                if logging_cog: await logging_cog.log_command_execution(interaction, False, "role (slash)", response, target=member)
        except discord.Forbidden:
            await self._send_error_embed(interaction, "Permission Error", f"I do not have permission to manage the role `{role.name}` for this member.")
            if logging_cog: await logging_cog.log_command_execution(interaction, False, "role (slash)", "Bot lacked role management permissions.", target=member)
        except Exception as e:
            await self._send_error_embed(interaction, "Role Error", f"An unexpected error: {e}")
            if logging_cog: await logging_cog.log_error(interaction.guild, "Role (slash) Error", str(e), ctx_or_interaction=interaction)

    # --- HELP (Corrected to use dynamic server prefix) ---
    @commands.command(name="help", aliases=['h', 'commands'], help="Shows help for commands or a specific command.\nUsage: ?help [command_name]", description="Shows help for commands or a specific command.")
    async def help_prefix(self, ctx: commands.Context, *, command_name: Optional[str] = None):
        logging_cog = self.get_logging_cog()
        # Correctly determine the prefix to use for displaying help
        current_prefix = self.server_prefixes.get(str(ctx.guild.id), self.default_prefix) if ctx.guild else self.default_prefix

        if command_name:
            command = self.bot.get_command(command_name) 
            if command and not command.hidden:
                embed = discord.Embed(title=f"ℹ️ Help: {current_prefix}{command.qualified_name}",
                                      description=command.description or command.help or "No detailed help available.",
                                      color=discord.Color.teal(), timestamp=datetime.datetime.now(datetime.timezone.utc))
                if ctx.author.display_avatar:
                     embed.set_author(name=str(ctx.author), icon_url=ctx.author.display_avatar.url)
                
                # Construct usage with the correct current_prefix
                usage = f"`{current_prefix}{command.qualified_name}"
                for param_name, param_obj in command.params.items():
                    if param_name not in ('self', 'ctx'):
                        usage += f" <{param_name}>" if param_obj.required and param_obj.default is param_obj.empty else f" [{param_name}]"
                usage += "`"
                embed.add_field(name="📝 Text Usage", value=usage, inline=False) 
                if command.aliases:
                    embed.add_field(name="📜 Aliases", value=", ".join([f"`{current_prefix}{a}`" for a in command.aliases]), inline=False)
                
                app_command_obj = None
                try: 
                    app_command_obj = self.bot.tree.get_command(command.name, guild=ctx.guild) 
                    if not app_command_obj and ctx.guild : 
                        app_command_obj = self.bot.tree.get_command(command.name)
                except Exception: pass

                if app_command_obj and isinstance(app_command_obj, app_commands.Command): 
                    slash_usage_str = f"`/{app_command_obj.name}"
                    options_desc_list = []
                    # Check if app_command_obj.options exists and is iterable
                    if hasattr(app_command_obj, 'options') and app_command_obj.options is not None:
                        for option in app_command_obj.options:
                            options_desc_list.append(f"`{option.name}` ({'required' if option.required else 'optional'}): {option.description or 'No description'}")
                    slash_usage_str += "`"
                    
                    if options_desc_list:
                         embed.add_field(name=f"⚙️ Slash Command (`/{app_command_obj.name}`)", 
                                        value="\n".join(options_desc_list), 
                                        inline=False)
                    else:
                         embed.add_field(name=f"⚙️ Slash Command", value=f"Available as: `/{app_command_obj.name}`", inline=False)
                
                required_perms_list = []
                if command.checks:
                    for check_func in command.checks:
                        if "has_permissions" in str(check_func): 
                            try:
                                perms_dict = check_func.__closure__[0].cell_contents # type: ignore
                                required_perms_list.extend([p.replace('_', ' ').title() for p, v in perms_dict.items() if v])
                            except: pass 
                if required_perms_list:
                    embed.add_field(name="🔑 Required Permissions", value=", ".join(list(set(required_perms_list))), inline=False)

                await ctx.send(embed=embed)
                if logging_cog: await logging_cog.log_command_execution(ctx, True, "help (prefix)", f"For command: {command.qualified_name}")
            else:
                await self._send_error_embed(ctx, "Help Error", f"Command `{command_name}` not found or is hidden.")
                if logging_cog: await logging_cog.log_command_execution(ctx, False, "help (prefix)", f"Command not found: {command_name}")
        else: 
            embed = discord.Embed(title=f"{self.bot.user.name} Help",
                                  description=f"Use `{current_prefix}help <command>` for specific info on a prefix command.\nServer Prefix: `{current_prefix}`\nSlash commands are also available!",
                                  color=discord.Color.purple(), timestamp=datetime.datetime.now(datetime.timezone.utc))
            if self.bot.user and self.bot.user.display_avatar: embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            if ctx.author.display_avatar: embed.set_author(name=str(ctx.author), icon_url=ctx.author.display_avatar.url)

            for cog_name, cog_instance in self.bot.cogs.items():
                if cog_name in ["Jishaku", "LoggingCog"]: continue
                
                prefix_cmds_text_list = []
                for cmd in sorted(cog_instance.get_commands(), key=lambda c: c.name): 
                    if isinstance(cmd, commands.Command) and not cmd.hidden: 
                        desc = cmd.short_doc or cmd.description or "No description"
                        prefix_cmds_text_list.append(f"`{current_prefix}{cmd.name}` - {desc}") # Use current_prefix
                
                if prefix_cmds_text_list:
                    embed.add_field(name=f"**{cog_name} (Prefix Commands)**", value="\n".join(prefix_cmds_text_list), inline=False)
            
            embed.add_field(name="**Slash Commands**", value="Many commands are also available as slash commands (e.g., `/ping`, `/kick`). Type `/help` to see available slash commands.", inline=False)
            embed.set_footer(text="Tip: Slash commands often provide argument choices directly!")
            await ctx.send(embed=embed)
            if logging_cog: await logging_cog.log_command_execution(ctx, True, "help (prefix)", "General help")

    @app_commands.command(name="help", description="Shows a list of available slash commands and their descriptions.")
    async def help_slash(self, interaction: discord.Interaction):
        logging_cog = self.get_logging_cog()
        
        embed = discord.Embed(
            title=f"ℹ️ {self.bot.user.name} Slash Command Help",
            description="Here is a list of available slash commands:",
            color=discord.Color.purple(),
            timestamp=datetime.datetime.now(datetime.timezone.utc)
        )
        if self.bot.user and self.bot.user.display_avatar:
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        
        if interaction.user.display_avatar: # Should always exist for an interaction user
            embed.set_author(name=str(interaction.user), icon_url=interaction.user.display_avatar.url)

        # --- CORRECTED LOGIC TO LIST SLASH COMMANDS ---
        cogs_with_slash_commands = {} # Store as {cog_name: [command_strings]}

        # Get all slash commands (global and for the current guild if any)
        all_app_commands_from_tree = []
        all_app_commands_from_tree.extend(self.bot.tree.get_commands(type=discord.AppCommandType.chat_input)) # Global
        if interaction.guild:
            all_app_commands_from_tree.extend(self.bot.tree.get_commands(guild=interaction.guild, type=discord.AppCommandType.chat_input))
        
        processed_command_names = set()
        unique_app_commands_to_display = []
        for cmd_obj in all_app_commands_from_tree:
            if cmd_obj.name not in processed_command_names:
                unique_app_commands_to_display.append(cmd_obj)
                processed_command_names.add(cmd_obj.name)

        for cmd_obj in sorted(unique_app_commands_to_display, key=lambda c: c.name):
            # We only want to display top-level chat input commands here
            if cmd_obj.parent is None: 
                cog_display_name = "General Commands" # Default if no cog or cog has no specific name
                
                # cmd_obj.binding is the cog instance the app command is bound to.
                if cmd_obj.binding and hasattr(cmd_obj.binding, 'qualified_name'):
                    cog_display_name = cmd_obj.binding.qualified_name
                
                # Skip internal cogs from being displayed as categories
                if cog_display_name in ["Jishaku", "LoggingCog"]:
                    cog_display_name = "Utility Commands" # Re-categorize if from an internal cog

                if cog_display_name not in cogs_with_slash_commands:
                    cogs_with_slash_commands[cog_display_name] = []
                
                desc = cmd_obj.description or "No description provided."
                cogs_with_slash_commands[cog_display_name].append(f"`/{cmd_obj.name}` - {desc}")

        if cogs_with_slash_commands:
            for cog_name, cmd_list_str_list in cogs_with_slash_commands.items():
                full_help_text = "\n".join(cmd_list_str_list)
                if len(full_help_text) > 1020: # Embed field value limit
                    full_help_text = full_help_text[:1020] + "\n... (list truncated)"
                embed.add_field(name=f"**{cog_name}**", value=full_help_text, inline=False)
        else:
            embed.add_field(name="Available Slash Commands", value="No slash commands found or I couldn't list them at this time.", inline=False)

        current_prefix = self.server_prefixes.get(str(interaction.guild_id), self.default_prefix) if interaction.guild_id else self.default_prefix
        embed.set_footer(text=f"For prefix commands (e.g., {current_prefix}ping), use {current_prefix}help.")

        await interaction.response.send_message(embed=embed, ephemeral=False)
        if logging_cog:
            await logging_cog.log_command_execution(interaction, True, "help (slash)", "Displayed slash command list.")


async def setup(bot: commands.Bot):
    config = {}
    try:
        with open("config.json", "r") as f: config = json.load(f)
    except Exception as e: print(f"CommandsCog Setup: Error loading config.json: {e}. Using defaults.")

    warnings_file = config.get("WARNINGS_FILE", "warnings.json")
    prefixes_file = config.get("PREFIXES_FILE", "prefixes.json")
    default_prefix = config.get("DEFAULT_PREFIX", "?")
    
    await bot.add_cog(CommandsCog(bot, warnings_file, prefixes_file, default_prefix))
    print("CommandsCog loaded (with all commands and fixes).")