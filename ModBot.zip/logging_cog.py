import discord
from discord.ext import commands
from discord.utils import escape_markdown
import datetime
import json
import re # Import the re module for regular expressions
from typing import Optional, Union, List


class LoggingCog(commands.Cog):
    def __init__(self, bot: commands.Bot, action_log_names: List[str], error_log_names: List[str]):
        self.bot = bot
        self.action_log_channel_names = action_log_names
        self.error_log_channel_names = error_log_names
        print(f"LoggingCog Initialized. Action log channels: {self.action_log_channel_names}, Error log channels: {self.error_log_channel_names}")

    def _get_specific_log_channel(self, guild: Optional[discord.Guild], channel_names_list: List[str]) -> Optional[discord.TextChannel]:
        """Helper to find a log channel by name in a guild, robustly handling emojis."""
        if not guild or not channel_names_list:
            return None

        # Regex to remove common emojis. This pattern might need refinement for very obscure unicode characters.
        # It targets common Unicode emoji blocks.
        emoji_pattern = re.compile(
            "["
            "\U0001F600-\U0001F64F"  # emoticons
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map symbols
            "\U0001F1E0-\U0001F1FF"  # flags (iOS)
            "\U00002702-\U000027B0"  # Dingbats
            "\U000024C2-\U0001F251" 
            "]+", flags=re.UNICODE
        )

        for configured_name in channel_names_list:
            # Clean the configured name by removing emojis and converting to lower case
            cleaned_configured_name = emoji_pattern.sub(r'', configured_name).strip().lower()

            for channel in guild.text_channels:
                # Clean the actual Discord channel name by removing emojis and converting to lower case
                cleaned_channel_name = emoji_pattern.sub(r'', channel.name).strip().lower()

                if cleaned_channel_name == cleaned_configured_name:
                    # Check if the bot has permissions to send messages and embed links
                    if channel.permissions_for(guild.me).send_messages and \
                       channel.permissions_for(guild.me).embed_links:
                        return channel
                    else:
                        print(f"LogCog: Found channel '{channel.name}' in '{guild.name}' but bot lacks Send Messages or Embed Links permissions.")
        return None

    def get_action_log_channel(self, guild: Optional[discord.Guild]) -> Optional[discord.TextChannel]:
        """Returns the action log channel for a given guild."""
        return self._get_specific_log_channel(guild, self.action_log_channel_names)

    def get_error_log_channel(self, guild: Optional[discord.Guild]) -> Optional[discord.TextChannel]:
        """Returns the error log channel for a given guild."""
        return self._get_specific_log_channel(guild, self.error_log_channel_names)

    def create_embed(self, title: str, description: str, color: discord.Color = discord.Color.blurple(),
                     actor: Optional[Union[discord.User, discord.Member]] = None, 
                     thumbnail_url: Optional[str] = None, 
                     ctx_or_interaction: Optional[Union[commands.Context, discord.Interaction]] = None) -> discord.Embed:
        """Creates a standardized embed for logging."""
        embed = discord.Embed(title=title, description=description, color=color, timestamp=datetime.datetime.now(datetime.timezone.utc))
        
        effective_actor = actor 
        if not effective_actor and ctx_or_interaction: 
            if isinstance(ctx_or_interaction, commands.Context):
                effective_actor = ctx_or_interaction.author
            elif isinstance(ctx_or_interaction, discord.Interaction):
                effective_actor = ctx_or_interaction.user

        if effective_actor:
            embed.set_author(name=str(effective_actor), icon_url=effective_actor.display_avatar.url)
            embed.set_footer(text=f"Actor ID: {effective_actor.id}")
            if thumbnail_url: 
                embed.set_thumbnail(url=thumbnail_url)
            elif hasattr(effective_actor, 'display_avatar') and effective_actor.display_avatar: 
                embed.set_thumbnail(url=effective_actor.display_avatar.url)
        else: # Fallback if no specific actor is provided
            embed.set_author(name=str(self.bot.user), icon_url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"Bot ID: {self.bot.user.id}")

        return embed

    async def log_command_execution(self, ctx_or_interaction: Union[commands.Context, discord.Interaction], success: bool,
                                    command_name: str, details: str = "",
                                    target: Optional[Union[discord.Member, discord.User, discord.TextChannel, str]] = None):
        """Logs the execution of a command."""
        guild = ctx_or_interaction.guild
        if not guild: return 

        log_channel = self.get_action_log_channel(guild)
        if not log_channel:
            print(f"LogCog: Action log channel not found for guild '{guild.name}' ({guild.id}).")
            return

        status_emoji = "✅" if success else "❌"
        title = f"{status_emoji} Command: {command_name}" 
        color = discord.Color.green() if success else discord.Color.orange()
        
        actor = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author
        channel_obj = ctx_or_interaction.channel 

        description_parts = [f"**User:** {actor.mention} (`{actor.id}`)"] 
        channel_mention = channel_obj.mention if hasattr(channel_obj, 'mention') else (f"`#{channel_obj.name}`" if hasattr(channel_obj, 'name') else "N/A")
        description_parts.append(f"**In:** {channel_mention}")

        if target:
            if isinstance(target, (discord.Member, discord.User)):
                description_parts.append(f"**Target User:** {target.mention} (`{target.id}`)") 
            elif isinstance(target, discord.TextChannel):
                description_parts.append(f"**Target Channel:** {target.mention}") 
            else:
                description_parts.append(f"**Target/Info:** `{str(target)}`")
        if details:
            description_parts.append(f"**Details:** {details}")

        embed = self.create_embed(title, "\n".join(description_parts), color, actor=actor, ctx_or_interaction=ctx_or_interaction)
        try:
            await log_channel.send(embed=embed)
        except Exception as e:
            print(f"LogCog: Error sending command execution log to {log_channel.name} in {guild.name}: {e}")

    async def log_error(self, guild: Optional[discord.Guild], error_title: str, error_description: str,
                        ctx_or_interaction: Optional[Union[commands.Context, discord.Interaction]] = None, level: str = "ERROR"): 
        """Logs an error or warning."""
        log_channel = self.get_error_log_channel(guild) 
        
        color = discord.Color.red()
        if level.upper() == "WARNING": color = discord.Color.gold() 
        elif level.upper() == "CRITICAL": color = discord.Color.dark_red() 

        actor_for_embed = None
        if ctx_or_interaction:
            actor_for_embed = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author

        embed = self.create_embed(f"🔩 {level.upper()}: {error_title}", error_description, color, actor=actor_for_embed, ctx_or_interaction=ctx_or_interaction)

        if log_channel:
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog: Error sending error log to {log_channel.name} in {guild.name if guild else 'Global'}: {e}")
                print(f"Original Error (Console Fallback): [{error_title}] {error_description}") 
        else:
            print(f"LogCog: Error log channel not found for guild '{guild.name if guild else 'Global'}'.")
            print(f"Original Error (Console): [{error_title}] {error_description}") 

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Logs when a member joins the guild."""
        log_channel = self.get_action_log_channel(member.guild)
        if log_channel:
            embed = self.create_embed("📥 Member Joined", f"{member.mention} (`{member.id}`) joined.", discord.Color.green(), actor=member)
            try: await log_channel.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_join): {e}")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        log_channel = self.get_action_log_channel(member.guild)
        if log_channel:
            action_by_str = "Unknown"
            reason_str = "Left the server" # Default reason
            action_found = False
            
            try:
                # Check for a KICK audit log entry first
                async for entry in member.guild.audit_logs(limit=1, action=discord.AuditLogAction.kick, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=10)):
                    if entry.target and entry.target.id == member.id:
                        action_by_str = entry.user.mention if entry.user else "Unknown Moderator"
                        reason_str = f"was kicked (Reason: {entry.reason or 'N/A'})"
                        action_found = True
                        break
                
                # If not kicked, check for a BAN audit log entry
                if not action_found:
                    async for entry in member.guild.audit_logs(limit=1, action=discord.AuditLogAction.ban, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=10)):
                        if entry.target and entry.target.id == member.id:
                            action_by_str = entry.user.mention if entry.user else "Unknown Moderator"
                            reason_str = f"was banned (Reason: {entry.reason or 'N/A'})"
                            action_found = True
                            break
            except discord.Forbidden: 
                reason_str += " (Audit log access denied)"
                print(f"LogCog: Missing permissions to read audit logs in guild {member.guild.name} for on_member_remove.")
            except Exception as e: 
                print(f"LogCog: Audit log fetch error for member remove: {type(e).__name__} - {e}")

            desc = f"{member.mention} (`{member.id}`) {reason_str}."
            if action_found and action_by_str != "Unknown":
                desc += f"\n**Action by:** {action_by_str}"
            
            embed = self.create_embed("📤 Member Left/Removed", desc, discord.Color.red(), actor=member)
            try: await log_channel.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_remove send): {e}")

            desc = f"{member.mention} (`{member.id}`) {reason}."
            if action_by != "Unknown" and reason.startswith(("Kicked", "Banned")):
                desc += f"\n**Action by:** {action_by}" # Added bolding for consistency
            embed = self.create_embed("📤 Member Left/Removed", desc, discord.Color.red(), actor=member)
            try: await log_channel.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_remove): {e}")
    
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        """Logs when a message is deleted."""
        if message.guild and not message.author.bot and (message.content or message.attachments or message.embeds):
            log_channel = self.get_action_log_channel(message.guild)
            if log_channel:
                content = escape_markdown(message.content) if message.content else ""
                if message.attachments: 
                    content += f"\n*({len(message.attachments)} attachment(s))* "
                    for att in message.attachments:
                        content += f"\n- {att.filename} (`{att.url}`)" # Add attachment info
                if message.embeds and not message.content: 
                    content += "\n*Message contained an embed.*"
                if not content.strip(): 
                    content = "*No displayable content (e.g., only sticker or complex embed)*"

                if len(content) > 1000: content = content[:1000] + "..."
                
                embed = self.create_embed(
                    "🗑️ Message Deleted",
                    f"**Author:** {message.author.mention} (`{message.author.id}`)\n" # Added user ID for clarity
                    f"**Channel:** {message.channel.mention}\n\n"
                    f"**Content**\n{content}", # Added "Content" heading
                    discord.Color.orange(),
                    actor=message.author,
                    thumbnail_url=None 
                )
                try: await log_channel.send(embed=embed)
                except Exception as e: print(f"LogCog Error (on_message_delete): {e}")

    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages: List[discord.Message]):
        """Logs when multiple messages are deleted (bulk delete)."""
        if not messages: return
        guild = messages[0].guild
        if not guild: return
        log_channel = self.get_action_log_channel(guild)
        if not log_channel: return
        
        source_channel_mention = messages[0].channel.mention if messages[0].channel else "Unknown Channel"
        count = len(messages)
        embed = self.create_embed(
            "🗑️ Bulk Messages Deleted",
            f"**{count}** messages were deleted in {source_channel_mention}.",
            discord.Color.dark_orange(),
            actor=self.bot.user, # Bot is the actor for bulk deletes
            thumbnail_url=None
        )
        try: await log_channel.send(embed=embed)
        except Exception as e: print(f"LogCog Error (on_bulk_message_delete): {e}")

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        """Logs when a message is edited."""
        if before.guild and not before.author.bot and before.content != after.content:
            log_channel = self.get_action_log_channel(before.guild)
            if log_channel:
                before_content = escape_markdown(before.content) if before.content else "*Empty*"
                after_content = escape_markdown(after.content) if after.content else "*Empty*"
                if len(before_content) > 500: before_content = before_content[:500] + "..."
                if len(after_content) > 500: after_content = after_content[:500] + "..."
                embed = self.create_embed(
                    "✏️ Message Edited",
                    f"**Author:** {before.author.mention} (`{before.author.id}`)\n" # Added author ID
                    f"**Channel:** {before.channel.mention} [Jump to Message]({after.jump_url})\n\n"
                    f"**Before**\n{before_content}\n\n" # Using code blocks for content
                    f"**After**\n{after_content}\n",
                    discord.Color.blue(),
                    actor=before.author,
                    thumbnail_url=None
                )
                try: await log_channel.send(embed=embed)
                except Exception as e: print(f"LogCog Error (on_message_edit): {e}")

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        """Logs when a channel is created."""
        log_ch = self.get_action_log_channel(channel.guild)
        if log_ch:
            ch_type = "Text" if isinstance(channel, discord.TextChannel) else \
                      "Voice" if isinstance(channel, discord.VoiceChannel) else \
                      "Category" if isinstance(channel, discord.CategoryChannel) else \
                      "Stage" if isinstance(channel, discord.StageChannel) else \
                      "Forum" if isinstance(channel, discord.ForumChannel) else "Unknown"
            embed = self.create_embed(f"📗 {ch_type} Channel Created", f"{ch_type} channel created: {channel.mention} (`{channel.name}`)", discord.Color.dark_green(), actor=self.bot.user) # Added bot as actor
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_channel_create): {e}")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        """Logs when a channel is deleted."""
        log_ch = self.get_action_log_channel(channel.guild)
        if log_ch:
            ch_type = "Text" if isinstance(channel, discord.TextChannel) else \
                      "Voice" if isinstance(channel, discord.VoiceChannel) else \
                      "Category" if isinstance(channel, discord.CategoryChannel) else \
                      "Stage" if isinstance(channel, discord.StageChannel) else \
                      "Forum" if isinstance(channel, discord.ForumChannel) else "Unknown"
            embed = self.create_embed(f"📕 {ch_type} Channel Deleted", f"{ch_type} channel deleted: `#{channel.name}` ({channel.id})", discord.Color.dark_red(), actor=self.bot.user) # Added bot as actor
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_channel_delete): {e}")
            
    # --- Channel name or type update ---
    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        """Logs when a channel's name or type is updated."""
        log_channel = self.get_action_log_channel(before.guild) # Use action log channel
        if not log_channel:
            return

        changes = []
        
        # Check for name change
        if before.name != after.name:
            changes.append(f"**Name:** `#{before.name}` → `#{after.name}`")

        # Check for channel type change (e.g., from text to voice, though less common)
        # Note: direct type conversion is rare; typically, a channel is deleted and recreated
        # but this handles potential edge cases or future Discord API changes.
        if before.type != after.type:
            changes.append(f"**Type:** `{before.type.name.capitalize()}` → `{after.type.name.capitalize()}`")

        # Check for category change
        if isinstance(before, discord.TextChannel) and isinstance(after, discord.TextChannel):
            if before.category != after.category:
                before_cat_name = before.category.name if before.category else "None"
                after_cat_name = after.category.name if after.category else "None"
                changes.append(f"**Category:** `{before_cat_name}` → `{after_cat_name}`")
        # Add more specific checks for other channel types if needed (e.g., nsfw, topic, bitrate for voice)
        if isinstance(before, discord.TextChannel) and isinstance(after, discord.TextChannel):
            if before.topic != after.topic:
                changes.append(f"**Topic changed.**") # Detail could be very long, just note change
            if before.nsfw != after.nsfw:
                changes.append(f"**NSFW status:** `{before.nsfw}` → `{after.nsfw}`")
        if isinstance(before, discord.VoiceChannel) and isinstance(after, discord.VoiceChannel):
            if before.bitrate != after.bitrate:
                changes.append(f"**Bitrate:** `{before.bitrate // 1000}kbps` → `{after.bitrate // 1000}kbps`")
            if before.user_limit != after.user_limit:
                changes.append(f"**User Limit:** `{before.user_limit or 'None'}` → `{after.user_limit or 'None'}`")

        if changes:
            ch_type = "Text" if isinstance(after, discord.TextChannel) else \
                      "Voice" if isinstance(after, discord.VoiceChannel) else \
                      "Category" if isinstance(after, discord.CategoryChannel) else \
                      "Stage" if isinstance(after, discord.StageChannel) else \
                      "Forum" if isinstance(after, discord.ForumChannel) else "Unknown"
            
            embed_desc = f"**Channel:** {after.mention} (`{after.id}`)\n\n" + "\n".join(changes)
            embed = self.create_embed(f"📝 {ch_type} Channel Updated", embed_desc, discord.Color.teal(), actor=self.bot.user)
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog Error (on_guild_channel_update): {e}")
    
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        """Logs when a role is created."""
        log_ch = self.get_action_log_channel(role.guild)
        if log_ch:
            embed = self.create_embed("➕ Role Created", f"New role: {role.mention} (`{role.name}`)", discord.Color.green(), actor=self.bot.user) # Added bot as actor
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_role_create): {e}")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        """Logs when a role is deleted."""
        log_ch = self.get_action_log_channel(role.guild)
        if log_ch:
            embed = self.create_embed("➖ Role Deleted", f"Role deleted: `{role.name}` ({role.id})", discord.Color.red(), actor=self.bot.user) # Added bot as actor
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_guild_role_delete): {e}")
            
    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        """Logs when a role is updated, including specific permission changes."""
        log_channel = self.get_action_log_channel(after.guild)
        if not log_channel:
            return

        changes = []

        if before.name != after.name:
            changes.append(f"**Name:** `{before.name}` → `{after.name}`")

        if before.color != after.color:
            changes.append(f"**Color:** `{before.color}` → `{after.color}`")

        # --- Detailed Permissions Change Logging ---
        if before.permissions != after.permissions:
            perm_changes_list = []
            
            # Iterate through all possible permissions
            for perm_name, value in iter(discord.Permissions()):
                # Get the state of the permission before and after
                before_has_perm = getattr(before.permissions, perm_name)
                after_has_perm = getattr(after.permissions, perm_name)

                if before_has_perm != after_has_perm:
                    if after_has_perm:
                        perm_changes_list.append(f"• **`{perm_name.replace('_', ' ').title()}`**: Granted ✅")
                    else:
                        perm_changes_list.append(f"• **`{perm_name.replace('_', ' ').title()}`**: Revoked ❌")
            
            if perm_changes_list:
                changes.append(f"**Permissions changed:**\n" + "\n".join(perm_changes_list))
            else:
                changes.append("**Permissions changed** (details not available due to internal mismatch, or no granular changes detected)")
        # --- End Permissions Change Logging ---

        if before.hoist != after.hoist:
            changes.append(f"**Display separately:** `{before.hoist}` → `{after.hoist}`")

        if before.mentionable != after.mentionable:
            changes.append(f"**Mentionable:** `{before.mentionable}` → `{after.mentionable}`")

        if changes:
            embed = self.create_embed(
                "🛠️ Role Updated",
                f"**Role:** {after.mention}\n\n" + "\n".join(changes),
                discord.Color.orange(),
                actor=self.bot.user
            )
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog Error (on_guild_role_update): {e}")
            
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Logs when a member's profile (nickname, roles, etc.) is updated."""
        log_channel = self.get_action_log_channel(after.guild) # Use get_action_log_channel for consistency
        if not log_channel:
            return

        changes = []

        if before.nick != after.nick:
            changes.append(f"**Nickname changed:** `{before.nick or 'None'}` → `{after.nick or 'None'}`")

        added_roles = [r for r in after.roles if r not in before.roles]
        removed_roles = [r for r in before.roles if r not in after.roles]

        if added_roles:
            changes.append(f"**Roles added:** {', '.join(r.mention for r in added_roles)}")
        if removed_roles:
            changes.append(f"**Roles removed:** {', '.join(r.mention for r in removed_roles)}")

        if changes:
            embed = self.create_embed(
                "🔁 Member Updated", 
                f"**Member:** {after.mention} (`{after.id}`)\n\n" + "\n".join(changes), 
                discord.Color.blurple(), 
                actor=after # The member themselves are the actor for their own update
            )
            try: await log_channel.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_update): {e}")
    
    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: Union[discord.User, discord.Member]):
        """Logs when a member is banned."""
        log_ch = self.get_action_log_channel(guild)
        if log_ch:
            reason, moderator = "N/A", "Unknown"
            try:
                async for entry in guild.audit_logs(action=discord.AuditLogAction.ban, limit=1, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=5)): # Reduced time window
                    if entry.target.id == user.id: # Compare IDs
                        reason = entry.reason or "No reason provided"
                        moderator = entry.user.mention if entry.user else "Unknown"
                        break
            except discord.Forbidden: 
                print(f"LogCog: Missing permissions to read audit logs for ban event in guild {guild.name}.")
            except Exception as e: 
                print(f"LogCog Error (on_member_ban audit log): {e}")

            embed = self.create_embed("🔨 Member Banned", f"{user.mention} (`{user.id}`) was banned.\n**Moderator:** {moderator}\n**Reason:** {reason}", discord.Color.dark_red(), actor=user) # Changed event to direct action
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_ban event): {e}")

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        """Logs when a member is unbanned."""
        log_ch = self.get_action_log_channel(guild)
        if log_ch:
            reason, moderator = "N/A", "Unknown"
            try:
                async for entry in guild.audit_logs(action=discord.AuditLogAction.unban, limit=1, after=datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(seconds=5)): # Reduced time window
                    if entry.target.id == user.id: # Compare IDs
                        reason = entry.reason or "No reason provided"
                        moderator = entry.user.mention if entry.user else "Unknown"
                        break
            except discord.Forbidden: 
                print(f"LogCog: Missing permissions to read audit logs for unban event in guild {guild.name}.")
            except Exception as e: 
                print(f"LogCog Error (on_member_unban audit log): {e}")

            embed = self.create_embed("✅ Member Unbanned", f"{user.mention} (`{user.id}`) was unbanned.\n**Moderator:** {moderator}\n**Reason:** {reason}", discord.Color.dark_green(), actor=user) # Changed event to direct action
            try: await log_ch.send(embed=embed)
            except Exception as e: print(f"LogCog Error (on_member_unban event): {e}")
    
    async def log_moderation_action(self, 
                                    ctx_or_interaction: Union[commands.Context, discord.Interaction], 
                                    title: str, description: str, color: discord.Color,
                                    target_user: Union[discord.Member, discord.User]):
        """A generic function to log various moderation actions."""
        guild = ctx_or_interaction.guild
        if not guild: return
        log_channel = self.get_action_log_channel(guild)
        if log_channel:
            moderator = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author
            desc_with_mod = f"**Moderator:** {moderator.mention} (`{moderator.id}`)\n" \
                            f"**Target:** {target_user.mention} (`{target_user.id}`)\n" \
                            f"{description}" # Added target user to description
            thumbnail_url_to_use = target_user.display_avatar.url if hasattr(target_user, 'display_avatar') and target_user.display_avatar else None
            embed = self.create_embed(title, desc_with_mod, color, actor=moderator, thumbnail_url=thumbnail_url_to_use, ctx_or_interaction=ctx_or_interaction)
            try:
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"LogCog: Error sending specific moderation action log to {log_channel.name} in {guild.name}: {e}")


async def setup(bot: commands.Bot):
    """Sets up the LoggingCog with action and error log channel names from config.json."""
    action_log_names, error_log_names = [], []
    try:
        with open("config.json", "r") as f: 
            config = json.load(f)
        action_log_names = config.get("ACTION_LOG_CHANNEL_NAMES", [])
        error_log_names = config.get("ERROR_LOG_CHANNEL_NAMES", [])
        if not isinstance(action_log_names, list): 
            print("Warning: ACTION_LOG_CHANNEL_NAMES in config.json is not a list. Using empty list.")
            action_log_names = []
        if not isinstance(error_log_names, list): 
            print("Warning: ERROR_LOG_CHANNEL_NAMES in config.json is not a list. Using empty list.")
            error_log_names = []
    except FileNotFoundError:
        print("LogCog Setup: config.json not found. Using empty channel lists.")
    except json.JSONDecodeError:
        print("LogCog Setup: Error decoding config.json. Please check its format. Using empty channel lists.")
    except Exception as e: 
        print(f"LogCog Setup: Unexpected error loading config: {e}. Using empty channel lists.")
    
    await bot.add_cog(LoggingCog(bot, action_log_names, error_log_names))
    print("LoggingCog loaded.")